THKHelp v1.1 by Harry Kakoulidis 12/1999
kcm@mailbox.gr
http://kakoulidis.homepage.com

This is Freeware. Please copy HKHelp11.zip unchanged.
If you find bugs, have options etc. Please send at my e-mail.

The use of this component is at your own risk.
I do not take any responsibility for any damages.

----------------------------------------------------------------

HKHelp is a pseudo-visual component to add help to any program, without help compilers etc. When a user selects a control, a customized pop-up window opens which can contain any text, even with different bullets, fonts, sizes, colors. Can also be used parallely with HLP's. The text displayed can be edited in a program like MS-Word or from HTML and the formatting is kept the same. All the data is compiled together in the exe. Very simple to use, only 1 line of code, everything is previewed in design time. Exe demo included.

Note: If you use this I would really like to be mentioned somewhere! 
However thats not necessary. At least send me a copy of your program.

How to use:
-----------
It's pretty simple, see the demo. Notice that I have included the word document which I used to format the help (only usefull of course for the programmer; the exe contains all that is necessary)

The only thing not so obvious is the fact that you edit your text in a RTF editor like MS-Word, copy what you want to the clipboard and then double click the "Paste" property to add it.

Also: If you are using a HLP file, note that the Help-Context of a control is copied to the pop-up help when opened. So if the user presses F1 from a pop-up window, the help is launced with the correct context.

Hint: In design time, double-click my component, and HelpMode will go on, so everything will function almost exactly as run-time! Only difference is that the pop-up will be modal. In run-time they are modelless, so the user can continue working with a pop-up open.

If you have any problems follow the steps:

1) Create your form. If it's a dialog, add a biHelp border Icon. If not add a button/menuitem that will be used for setting the program to helpmode. Add a THKHelp Component (only one per form).

2) If you did add a button write an OnClick event in it like:
 HKHelp.Helpmode:=not HKHelp.Helpmode;

This will make the mouse cursor crHelp and afterwards if the user selects a control, a pop-up will open.

3) In the object inspector, click the HelpWindows property. This will open a property editor, where you will connect controls and help texts.

4) Select add, and a new THelpItem will be created. Select it, and change the settings. Link the Control Property to the Control that you want to add help to.
 
5) Now go to your favorite text editor (ms-word, frontpage etc) and type in what you want displayed. Format it to your likes.

6) Select it and copy it to the clipboard. Now go back to delphi and Double-click "Paste". You are finished! Double-click "Test" to test.

7) Notice that the text in RTF Format is in the "RTF" property. Don't change it, unless you really know what you are doing. However note that you can put here a simple string, and that can be shown correctly.

