ButtonPanel (TKG_ButtonPanel)
I got tired of building applications in earlier versions of Delphi prior to
versions which offered "Anchors" property and had to reposition buttons at
the bottom of forms. So I created this component (although I am sure it could
have been done better).


Other then the demo for ADO/MDB/TreeView;

Installation:
  Install as you would any 3rd party component.


How to use (Basics):
  1. Place a panel on a form
  2. Place one or more TButtons on the panel
  3. Right click the panel
  4. Select "Buttons", click Ok

Note:
  If you rename the buttons after the above instructions you
  will need to rename them in the component button list.


Questions/Comments
  Kevin S. Gallagher
  gallaghe@teleport.com
  kevin.s.gallagher@state.or.us
