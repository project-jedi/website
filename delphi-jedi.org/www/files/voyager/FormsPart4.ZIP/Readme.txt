The component is required by the demo for this month.
You do not need to install it, I suggest placing the
zip file contents into the directory were you unzipped
the "Forms Part 4" demo. This way you can try the component
w/o installing it. If you like the component then install it.
