The zip file contains a neat example for traversing the registry.
It must have been compiled with D3 with runtime packages since
I got errors in D4. They are simple to fix. If you need help let
me know, I went thru it already.

Kevin