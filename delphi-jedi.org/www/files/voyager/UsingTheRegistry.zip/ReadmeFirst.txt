1) The DemoProject directory has a rather large size project for demoing
   various registry operations. I had to force myself to stop adding
   more to it.

2) The Extra directory contains a project that when compiled will 
   traverse the registry in search of un-used keys. It was created
   with D3 and if you try to run it w/o D3 packages, well it will not.
   Also there are somethings which must be done prior to compiling in
   D4 and higher. Upon opening the project allow it to get rid of the
   declaration for the panel, in the USES clause there is a unit which
   I don't have (can't remember) the name, simply remove it. Then there
   will be some minor things like DWORD comparing, typecast the API
   in question as an Integer. Then the project will compile.

Modifications
   KSG 07/25/00 Updated to work in D5

Kevin S. Gallagher
gallaghe@teleport.com