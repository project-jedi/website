The patterns project contains the code implementation of the
patterns presented in the document "Introduction to Patterns for
Delphi Developers" by Ader Gonzalez.

Please read Patterns_intro.doc for more information.