
WAVEFMTU.ZIP 

To the User:

Francois Piette wrote MSACM.pas from sundry MS headers (including mmreg.h) 
and before he donated it to Jedi I queried on c.l.p.d.m whether anyone had 
the full list of WAVE_FORMAT_???? constants which defined the Format Tag 
values for Audio Compression Manager drivers (these constants identify the 
particular codec algorithm - eg PCM etc). These constants were defined in 
mmreg.h which I did not have.


Francois gave me a copy of the values and I made a list of them together (for 
completeness) with some values which were already declared in MMSystem.pas.


When the Windows Media Author Audio Encoder (free download from MS) is 
installed a number of additional Format Tag values appear in the ACM and I 
added these to the list. Another driver also appeared when I installed a 
Philips SpeechMouse and has been added.


Anyone using ACM and not relying on the acmFormatChoose user interface (ie 
anyone doing "quiet" compression) will need access to this list to enable 
them to use MS constants to specify the particular codec they want to use - 
and the list is not in the Jedi MSACM.pas.

If you have the latest copy of mmreg.h (or similar) should check the Windows Media Author 
values for which I have allocated names - and correct the names if incorrect 
(but its better in my view to have the file as it is rather than nothing). 

I have already put in the ($EXTERNALSYM ???????} comments for the file.

Also included in the zip file is a copy of a program I wrote to enumerate all 
the ACM compression drivers and display some information about the codecs. 
This is an expansion of the information you can get by selecting Start | 
Control Panel | MultiMedia > Advanced < Audio Compression Codecs. Also 
included is the Delphi 3 source - it might be of interest to anyone just 
starting in using ACM.


Alan Lloyd
alanglloyd@aol.com


