DirectDraw & DirectSound wrapper classes for Delphi
---------------------------------------------------
Version 1.0 (19.4.98)

***
Please give me some feedback !! See Contact at bottom on how to contact me.
***

* Files

ddrawclasses.pas	the unit containing the wrapper classes for DirectDraw
dsoundclasses.pas	the unit containing the wrapper classes for DirectSound
dxtest1.pas		a project to test ddrawclasses & dsoundclasses
frmmain.pas		the main form
frmmain.dfm		the form file
frmtest1.pas	simple test using palette cycling & page flipping
frmtest1.dfm	the form file
frmtest2.pas	simple test using the graphic property & cliplists
frmtest2.dfm	the form file
frmtest3.pas	simple test using the components
frmtest3.dfm	the form file
frmtest4.pas	simple test for directsound part using directsound components
frmtest4.dfm	the form file
jmdirectxreg.pas	installs the directx wrapper components and register some additional property editors
jmdirectxreg.dcr	icons for the directx wrapper components
jmpackage.dpk	package file which can be used to install the components
jmpackage.res	resource file for package

* Installation

Nothing needs to be done if the classes are only used as wrappers. If the classes are 
used as  components, JMControls with the included editors is needed. Also the units WinExtra, 
VCLExtra & MMExtra are needed. These can all be downloaded from: http://www.delphi.club.tip.nl/
To install the components install the JMPACKAGE.DPK file supplied with this archive. Don't use 
the one supplied with JMControls.ZIP since that one only installes the JMControl components
and not the directX components.


* Usage & disclaimers

The ddrawclasses.pas & dsoundclasses.pas can be used and copied freely, so long the 
copyright notice and disclaimer are kept at the top of the source file. The wrapper 
classes were created as part of the JEDI project.

* Notes

This is the first version, released for testing mainly. The test program tests only some functions of the
classes. A few notes on using this unit:
- If you want additional support by IDirectDrawSurface2 & 3 disable FIRSTVERSION at the start of the
the unit file. This has been defined because of errors occuring when using IDirectDrawSurface2 & 3.

Look into the source file for more comments and information.

* Contact & Addresses

The main purpose of this release is testing of the classes and to get remarks by you. So please feel free
to mail any problem, bug or new improvements !

Mail: delphi@club.tip.nl
Web: http://www.delphi.club.tip.nl/

Jedi, a group of programmers converting API for Delphi and creating wrappers and components:
http://www.delphi-jedi.org/

Direct X API for Delphi:
http://www.sbox.tu-graz.ac.at/home/ungerik/DelphiGraphics/

***

Enjoy, Josha Munnik
