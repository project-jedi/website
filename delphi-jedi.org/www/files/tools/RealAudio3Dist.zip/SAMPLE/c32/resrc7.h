//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by RAsample.rc
//
#define IDBROWSEIN                      3
#define IDBROWSEOUT                     4
#define IDD_ENCODER                     101
#define IDC_EDIT_INPUT                  1000
#define IDC_EDIT_OUTPUT                 1001
#define IDC_EDIT_TITLE                  1002
#define IDC_EDIT_AUTHOR                 1003
#define IDC_EDIT_COPYRIGHT              1004
#define IDC_COMBO_CODEC                 1005
#define IDC_COMBO_SAMPLING              1006
#define IDC_COMBO_PCM                   1007
#define IDC_VERSIONLABEL                1008
#define IDEXIT                          1010
#define IDENCODE                        1011
#define IDC_BITSPERSAMPLE               1012
#define IDC_SAMPLINGRATE                1013
#define IDC_CHANNELS                    1014
#define IDENCABORT                      1015
#define IDC_WAVFILSIZ                   1015
#define IDC_SEL_RECORD                  1016
#define IDC_PERFECT_PLAY                1017
#define IDC_ABORT                       1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
