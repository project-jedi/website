/////////////////////////////////////////////////////////////////////////////
//
//	Encode.CPP
//
//	Interface with low-level Encoder API
//
//	John Burroughs		5/96
//	Adam Schaeffer		7/96
//	Kurt Howard			11/96
//
//	Copyright �1995,1996 Progressive Networks, Inc.
//	All Rights Reserved
//

#include "windows.h"
#include "commctrl.h"
#include "stdio.h"
#include "resrc7.h"
#include "RAsample.h"
#include "racodec.h"

#define Message(s)	MessageBox(NULL, s, "Real Audio Encoder", MB_OK)

extern HINSTANCE	hInstance;
extern BOOL			ENCODING;

// the encoder object
RA_Encoder			enc = NULL;

// a flavor handle
PNFlavorHandle		flavor;

PN_ERROR encode_wav(HWND, RA_Encoder, HANDLE, PN_AUDIO_FORMAT, ULONG32, BOOL);

void DoInit(HWND w)
{	
	// create a list of availible codecs which conform to the
	// content type we wish to encode
	RAenc_PackageInit(PN_CONTENT_VOICE | PN_CONTENT_MUSIC);

	// create an encoder
	enc = RAenc_Create();
	
	// choose the flavor we want to use, based on properties
	UINT16 numFlavors = RAenc_GetNumFlavors(enc);
	UINT16 index;
	char codecname[MAX_PATH];	
	void* flavname;
	UINT16 buflen;

	// grab the handle of the dialog's combo box, so we can add
	// codec flavors to it.
	HWND ctl = GetDlgItem(w, IDC_COMBO_CODEC);
	
	// iterate through all the flavors we found
	for (index = 0; index < numFlavors; index++)
	{
		if (RAenc_GetFlavorByIndex(enc, index, &flavor) != PN_NO_ERROR)
			Message("Bad flavor index!");
	  	else
		{
			// Grab the name of the flavor
			RAenc_GetFlavorProperty	(enc, flavor, FLV_PROP_NAME, &flavname, &buflen);

			// convert it into a string
			strncpy(codecname, (char*)flavname, buflen);

			// put it in the combo box
			SendMessage(ctl, CB_ADDSTRING, 0, (LPARAM)codecname);
		}	
	}	
	// set default value in the codec combo box
	SendMessage(GetDlgItem(w, IDC_COMBO_CODEC), CB_SETCURSEL, 0, 0);

	//  destroy the encoder
	RAenc_Destroy(enc);
}

void DoAbort(void)
{
	// abort the encoding process
	RAenc_Abort(enc, FALSE);
}

void DoEncode(HWND w, ENAPP_OPTIONS *pOptions)
{	//  here's where the sound file gets encoded.  We initialize the
	//  encoder with the desired codec, make a few adjustments based
	//  on the attributes of the sound data, and begin encoding.
	enc						= RAenc_Create();	
	HANDLE			fpin	= OpenWAVin(pOptions->_input);
	PN_AUDIO_FORMAT info	= ReadWAVheader(fpin);
	BOOL			convert	= FALSE;

	// legit WAV header?
	if (info.FormatTag)
	{	// get the desired codec flavor -- this was taken from the dialog's
		// combo box index when the 'Encode' button was clicked.
		if (RAenc_GetFlavorByIndex(enc, (UINT16)pOptions->_codec, &flavor) != PN_NO_ERROR) 
			Message("Bad flavor index!  Check your system for duplicate/obsolete codec DLLs");
		else 
		{	// before we go any further, let's check the stereo/mono match of our
			// clip.  We frequently turn stereo clips into mono (the encoder will
			// handle this), but going the other direction, it would be up to us
			// to double the samples in the buffer.  Instead, let's see how to query
			// the codec flavor properties for audio format information and prevent
			// that scenario from happening.
			void*	prop;
			UINT16	buflen;
			RAenc_GetFlavorProperty	(enc, flavor, FLV_PROP_INPUT_AUDIO_FORMAT, &prop, &buflen);
			PN_AUDIO_FORMAT* inputinfo = (PN_AUDIO_FORMAT *)prop; 		
			if (inputinfo->Channels > info.Channels)
				Message("Please choose a mono codec flavor to encode a mono clip.");
			else
			{	// encoder only likes 16 bit samples...we'll convert 8->16 if needed
				if (info.BitsPerSample == 8) 
				{	
					convert = TRUE;
					info.BitsPerSample = 16;
				}
				// initialize encoder with the desired codec flavor
				if (RAenc_InitializeEncoder(enc, flavor, &info))
					Message("Encoder failed to initialize!");
				else
				{	// we want to encode to a file, so set destination there
					RAenc_SetDestination(enc, PN_ENC_DEST_FILE);
					// give the encoder an output filename
					if (RAenc_SetOutputFile(enc, pOptions->_output))
						Message("Cannot open desired output file. Possible reasons:  The file may be corrupted, an unsupported format, or in use by another application.");
					else 
					{	// what size data chunks are we working with?  These are both in bytes
						// that is a change from 2.1
						ULONG32 bytesIn, bytesOut;
						// will the encoder do sample rate conversion?
						BOOL    reSample;
						RAenc_GetBufferSizes(enc, &bytesIn, &bytesOut, &reSample);
						if (reSample)
							Message("Encoder will perform resampling.");

						// set the clip's attributes
						RAenc_Title			(enc, pOptions->_title);
						RAenc_Author		(enc, pOptions->_author);
						RAenc_Copyright		(enc, pOptions->_copyright);

						RAenc_SelRecBit		(enc, pOptions->_selectiverecord);
						RAenc_PerfPlayBit	(enc, pOptions->_perfectplay);  
				
						// start the encoder
						RAenc_Start(enc);

						// encode and write the file
						encode_wav(w, enc, fpin, info, bytesIn, convert);

						//  tell the encoder to flush any remaining data and write
						//  the appropriate .RA file header data
						RAenc_Done(enc);
						
						// destroy the encoder
						RAenc_Destroy(enc);
					}
				}
			}
		}
	}						
	// finally, close the input WAV file
	CloseHandle(fpin);
}

//
//   encode WAV file
//

PN_ERROR encode_wav(HWND w, RA_Encoder enc, HANDLE fpin, PN_AUDIO_FORMAT info, ULONG32 bytesIn, BOOL convert)
{
	PN_ERROR theErr = PN_NO_ERROR;
	ULONG32	 i, n;
	ULONG32	 total_bytes_read	= 0;
    ULONG32	 data_size			= ReadLong(fpin);;
	ULONG32	 encode_size		= bytesIn;
	ULONG32	 read_size;
	
	// tmp BYTE array in case we need to convert 8-bit samples
	short *inBuf	= new short [bytesIn];
	BYTE  *tmpBuf	= new BYTE  [bytesIn / 2];
	BYTE  *buf;

	// set up the progress bar
	RECT rcClient;
	GetClientRect(w, &rcClient);
	int cyVScroll	= GetSystemMetrics(SM_CYVSCROLL);	
	HWND hwndPB = CreateWindowEx(0, PROGRESS_CLASS, (LPSTR)NULL, WS_CHILD | WS_VISIBLE, rcClient.left, rcClient.bottom - cyVScroll, rcClient.right, cyVScroll, w, (HMENU)0, hInstance, NULL);
	
	// to convert 8 bit -> 16 bit samples
	// we read 1/2 as many bytes to get the same number of samples
	// we'll stretch 'em out below
	if (convert) 
	{
		buf = tmpBuf;
		read_size = encode_size / 2;
	}
	else
	{
		buf = (BYTE *)inBuf;
		read_size = encode_size;
	}
	
	while ((ReadFile(fpin, buf, read_size, &n, NULL) > 0) && (total_bytes_read < data_size) && ENCODING)
	{						  
		total_bytes_read += n;
		
		// check to see if we need to zero out the buffer
		if (total_bytes_read > data_size)
		{
			total_bytes_read -= n;
			n = data_size - total_bytes_read;
			total_bytes_read += n;
			memset(&buf[n], 0, read_size - n);
		}

		// stretch 8-bit (unsigned) -> 16-bit (signed) samples
		// also re-adjust n before encoding stretched samples
		if (convert)
		{
			for (i = 0; i < n; i++)
				inBuf[i] = (buf[i] << 8) - 0x8000;
			
			n <<= 1;	// shift-left 1 == * 2
		}

		// we're encoding to a file, not a buffer -- thus, it really
		// doesn't matter what we pass in for outbuf, & timestamp
		ULONG32 outlen;
		
		RAenc_Encode(enc, inBuf, n, NULL, &outlen, NULL, &encode_size);
		
		// adjust next read_size for 8-bit samples if converting
		if (convert)
			read_size = encode_size / 2;
		else 
			read_size = encode_size;
		
		// let's do a progress indicator, so we know something's happening. 					
		SendMessage(hwndPB, PBM_SETPOS, (WPARAM)(100 * total_bytes_read / data_size), 0);

		// process any waiting messages
		MSG m;		
	
		while (PeekMessage(&m, NULL, 0, 0, PM_REMOVE) == TRUE)
		{
			if (m.message == WM_QUIT)
			{
				DestroyWindow(hwndPB);
				return theErr;
			}
			TranslateMessage(&m);
			DispatchMessage(&m);
		}
	}

	delete [] inBuf;
	delete [] tmpBuf;

	DestroyWindow(hwndPB);
	return theErr;
}

// this version is a wrapper for ReadWAVheader (below)

void GetWaveInfo(char *filename, long *sRate, int *sBits, int *sChannels, long *fSize) {
	HANDLE			hw	= OpenWAVin(filename);
	*fSize				= GetFileSize(hw, NULL);
	PN_AUDIO_FORMAT	fmt	= ReadWAVheader(hw);
	*sRate				= fmt.SamplesPerSec;
	*sBits				= fmt.BitsPerSample;
	*sChannels			= fmt.Channels;
	CloseHandle(hw);
}

HANDLE OpenWAVin(char *filename) {
	HANDLE fpin = CreateFile(filename, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	
	if (((int)fpin) <= 0)
		RaError("Couldn't open WAV file for input!");
	
	return fpin;
}

PN_AUDIO_FORMAT ReadWAVheader(HANDLE fp) {
	PN_AUDIO_FORMAT info = {0, 0, 0, 0};
	char	s[10];

	ULONG slen						= ReadString(fp, s, 4);
	if (strcmp(s, "RIFF"))  
		RaError("bad WAV header");
	else 
	{
		ULONG32	chunklen			= ReadLong(fp);	
		slen						= ReadString(fp, s, 8);	
		if (strcmp(s, "WAVEfmt "))
			RaError(s);
		else 
		{ 
			chunklen				= ReadLong	(fp);	
			UINT16	format			= ReadShort	(fp);
			UINT16	channels		= ReadShort	(fp);	
			ULONG32	samplerate		= ReadLong	(fp);
			ULONG32	bytespersec		= ReadLong	(fp);
			UINT16	bytesperframe	= ReadShort	(fp);
			UINT16	samplesize		= ReadShort	(fp);
			// we've read 16 bytes
			// read (and ignore) any extra bytes in this chunk
			chunklen -= 16;
			while (chunklen--)
				ReadByte(fp);
			
			// wade thru any chunks up to "data" chunk (end of header)
			slen = ReadString(fp, s, 4);
			while (strcmp(s, "data")) 
			{
				chunklen = ReadLong(fp);
				while (chunklen--) 
					ReadByte(fp);
				slen = ReadString(fp, s, 4);
			}
			// the next thing we read will be the data chunk size
			// fill in PN_AUDIO_FORMAT struct
			info.FormatTag		= 1;
			info.SamplesPerSec	= samplerate;
			info.BitsPerSample	= samplesize;
			info.Channels		= channels;
		}
	}
	return info;
}

// binary data r/w utilities
// read
BYTE ReadByte(HANDLE fp) {
	BYTE buf;
	ULONG32 n;

	ReadFile(fp, &buf, 1, &n, NULL);  
	return buf; 
}

UINT16 ReadShort(HANDLE fp) {
	UINT16 buf;
	ULONG32 n;

	ReadFile(fp, &buf, 2, &n, NULL);
	return buf; 
}

ULONG32 ReadLong(HANDLE fp) {
	ULONG32 buf;
	ULONG32 n;

	ReadFile(fp, &buf, 4, &n, NULL);
	return buf; 
}

ULONG32 ReadString(HANDLE fp, char *buf, DWORD len) {
	ULONG32 n;

	ReadFile(fp, buf, len, &n, NULL);
	// zero terminate the string
	buf[n] = '\0';
	return n; 
}

void RaError(char *errstr) {	
	Message(errstr);
}
