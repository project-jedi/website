/////////////////////////////////////////////////////////////////////////////
//
//      RAsample.CPP
//
//  	Implementation of the ra_enapp dialog box.  This code handles
//		UI interaction.
//
//      John Burroughs          5/96
//		Adam Schaeffer			7/96
//		Kurt Howard				11/96
//
//	Copyright �1995,1996 Progressive Networks, Inc.
//	All Rights Reserved
//      

#include <windows.h>
#include "resrc7.h"

#ifndef _WIN32
#include <commdlg.h>
#endif	// _WIN32

#include "RAsample.h"

HINSTANCE hInstance;
BOOL ENCODING = FALSE;

extern RA_Encoder enc;

extern "C"
{
	int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR cmdLine, int nCmdShow);
	BOOL CALLBACK EncoderDlgProc(HWND, UINT, WPARAM, LPARAM);
}

BOOL CALLBACK EncoderDlgProc(HWND w, UINT cmd, WPARAM wP, LPARAM lP)
{
	HWND			ctl;
	UINT			code, id;
	ENAPP_OPTIONS * pOptions;
	ULONG32			Version;
	int				Major, Minor, Release, Build;
	char			VersionString[128];
	char			fileBuffer[MAX_PATH];

	switch(cmd)
	{
	case WM_INITDIALOG:
		// initialize options structure and stash pointer away for later
		
		// set up the encoder & get combo box codec options
		DoInit(w);
		
		SetWindowLong(w, DWL_USER, lP);

		// show some version info
		Version = RAenc_ProductVersion();

		Major   = RAENC_GET_MAJOR_VERSION(Version);
 		Minor   = RAENC_GET_MINOR_VERSION(Version);
		Release = RAENC_GET_RELEASE_NUMBER(Version);
		Build   = RAENC_GET_BUILD_NUMBER(Version);

		wsprintf(VersionString, "%d.%d.%d.%d", Major, Minor, Release, Build);
		SetDlgItemText(w, IDC_VERSIONLABEL, VersionString);

		break;

	case WM_CLOSE:
		// shut down the encoder and quit the app
		SendMessage(w, WM_COMMAND, IDEXIT, NULL);

		break;
	
	case WM_DESTROY:
		// shut down the encoder
		RAenc_PackageRelease();
		
		break;
	
	case WM_COMMAND:
		code = HIWORD(7); 
		id = LOWORD(wP);
		ctl = (HWND) lP;

		switch(id)
		{
		case IDBROWSEIN:
			// find a file to encode
			if (BrowseForFile(fileBuffer, MAX_PATH, TRUE))
			{
				SetDlgItemText(w, IDC_EDIT_INPUT, fileBuffer);
					
				// try to get some file info
				pOptions = (ENAPP_OPTIONS*) GetWindowLong(w, DWL_USER);
				strcpy(&pOptions->_input[0], fileBuffer);
				long sRate, fSize;
				int sBits, sChannels;
				char waveInfoText[10];

				GetWaveInfo(fileBuffer, &sRate, &sBits, &sChannels, &fSize);

				wsprintf(waveInfoText, "%d", sRate); 
				SetDlgItemText(w, IDC_SAMPLINGRATE, waveInfoText);
				wsprintf(waveInfoText, "%d", sBits);
				SetDlgItemText(w, IDC_BITSPERSAMPLE, waveInfoText);
				wsprintf(waveInfoText, "%d KB", fSize / 1024);
				SetDlgItemText(w, IDC_WAVFILSIZ, waveInfoText);				
				SetDlgItemText(w, IDC_CHANNELS, sChannels == 1 ? "Mono" : "Stereo");
			}
			
			break;

		case IDBROWSEOUT:
			// choose the name of the output file
			if (BrowseForFile(fileBuffer, MAX_PATH, FALSE))
			{
				SetDlgItemText(w, IDC_EDIT_OUTPUT, fileBuffer);
			}	
			break;
		
		case IDENCODE:
			// fill out structure based on control contents
			pOptions = (ENAPP_OPTIONS*) GetWindowLong(w, DWL_USER);

			// get text fields
			GetDlgItemText(w, IDC_EDIT_INPUT, &pOptions->_input[0], MAX_PATH);
			GetDlgItemText(w, IDC_EDIT_OUTPUT, &pOptions->_output[0], MAX_PATH);
			GetDlgItemText(w, IDC_EDIT_TITLE, &pOptions->_title[0], MAX_CAPTION);
			GetDlgItemText(w, IDC_EDIT_AUTHOR, &pOptions->_author[0], MAX_CAPTION);
			GetDlgItemText(w, IDC_EDIT_COPYRIGHT, &pOptions->_copyright[0], MAX_CAPTION);
			
			pOptions->_selectiverecord = IsDlgButtonChecked(w, IDC_SEL_RECORD);
			pOptions->_perfectplay = IsDlgButtonChecked(w, IDC_PERFECT_PLAY);

			// get codec index from combo box
			pOptions->_codec = SendMessage(GetDlgItem(w, IDC_COMBO_CODEC), CB_GETCURSEL, 0, 0);
	
			// perform the file encoding....
			HCURSOR oldCursor;
			
			if (strlen(pOptions->_input) > 0 && strlen(pOptions->_output) > 0 )
			{
				// change to busy cursor
				oldCursor = SetCursor(LoadCursor(NULL, IDC_WAIT));
				
				// begin encoding
				ENCODING = TRUE;
				
				DoEncode(w, pOptions);
				ENCODING = FALSE;

				// restore default cursor
				SetCursor(oldCursor);
			} 
			else
			{
				MessageBox(NULL, "You need an input and an output file in order to continue", "Encoder Error", MB_OK);
			}

			break;

		case IDC_ABORT:
			ENCODING = FALSE;
			DoAbort();
			
			MessageBox(w, "Encoding process interrupted!", "Encode Error", MB_OK);

			break;
		
		case IDEXIT:
			EndDialog(w, FALSE);
			break;
		}
		break;
	}
	return FALSE;
}


/////////////////////////////////////////////////////////////////////////
//
// 	BrowseForFile()
//
//	Parameters:
//		char* fileBuffer
//		int   fileBufferLen
//		BOOL  BrowseIn
//
//	Returns:
//		BOOL  Success or failure value of function
//
//	Purpose:
//		This code is called when we want to find filenames.  The
//		BrowseIn flag tells us whether we're looking for an input
//		or and output file.	If 'BrowseIn' is TRUE, then we're looking
//		for the input file.  If FALSE, then we want an output filename.
//
//

BOOL BrowseForFile(char* fileBuffer, int fileBufferLen, BOOL BrowseIn)
{
	char szWavFilter[] = "WAV Files (*.wav)\0*.wav\0";
	char szRaFilter[] = "RealAudio Files (*.ra)\0*.ra\0";
	
	char szInputTitle[] = "Choose a File to Encode:";
	char szOutputTitle[] = "Choose an Output Filename:";
	
	char szFile[MAX_PATH];
	memset(&szFile, 0, MAX_PATH);
	
	OPENFILENAME  ofn;

	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.lpstrFilter = NULL;
	ofn.lpstrTitle = NULL;
	ofn.hwndOwner = GetActiveWindow();
	ofn.hInstance = hInstance;
	ofn.lpstrCustomFilter = NULL;
	ofn.nMaxCustFilter = 0;
	ofn.nFilterIndex = 1;
	ofn.lpstrFile = szFile;
	ofn.nMaxFile = MAX_PATH;
	ofn.lpstrFileTitle = NULL;
	ofn.nMaxFileTitle = MAX_PATH;
	ofn.lpstrInitialDir = NULL;
	ofn.nFileOffset = 0;
	ofn.nFileExtension = 0;
	ofn.lpstrDefExt = "ra";
	ofn.lCustData = 0;
	ofn.lpfnHook = NULL;
	ofn.lpTemplateName = NULL;

	// are we looking for a .WAV file or an .RA file?
	BOOL foundFile = FALSE;
	
	// are we looking to read or write a file?
	if (BrowseIn)
	{
		ofn.lpstrFilter = szWavFilter;
		ofn.lpstrTitle = szInputTitle;
		ofn.Flags = OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
		foundFile = GetOpenFileName(&ofn);
	}
	else
	{
		ofn.lpstrFilter = szRaFilter;
		ofn.lpstrTitle = szOutputTitle;
		ofn.Flags = OFN_PATHMUSTEXIST | OFN_OVERWRITEPROMPT;
		foundFile = GetSaveFileName(&ofn);
	}

	// snag a filename with the common file dialog
	if ( foundFile && ( (int)strlen(ofn.lpstrFile) <= fileBufferLen) )
	{
		lstrcpy(fileBuffer, ofn.lpstrFile);
		return TRUE;
	} 
	else
	{
		return FALSE;
	}
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR cmdLine, int nCmdShow)
{
	ENAPP_OPTIONS options;

	hInstance = hInst;
	
	DialogBoxParam(hInst, MAKEINTRESOURCE(IDD_ENCODER), NULL, 
						(DLGPROC) EncoderDlgProc, 
						(LPARAM)(LPVOID)&options);

	return 0;
}


/*******************************/
