//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by gen32.rc
//
#define IDR_GENERIC                     101
#define IDI_APP                         102
#define IDD_ABOUTBOX                    103
#define IDD_OPEN_URL                    106
#define IDD_OPEN_HTTP                   107
#define IDC_FILEDESCRIPTION             1000
#define IDC_PRODUCTVERSION              1001
#define IDC_LEGALCOPYRIGHT              1002
#define IDC_COMPANYNAME                 1003
#define IDC_LEGALTRADEMARKS             1004
#define IDC_TICKS                       1005
#define IDC_TICK_STATIC                 1006
#define IDC_SERVER                      1006
#define IDC_PERMSG                      1007
#define IDC_RESOURCE                    1007
#define IDC_TICK_STATIC2                1008
#define IDM_NEW                         40001
#define IDM_OPEN                        40002
#define IDM_SAVE                        40003
#define IDM_SAVEAS                      40004
#define IDM_PRINT                       40005
#define IDM_PRINTSETUP                  40006
#define IDM_EXIT                        40007
#define IDM_UNDO                        40008
#define IDM_CUT                         40009
#define IDM_COPY                        40010
#define IDM_PASTE                       40011
#define IDM_LINK                        40012
#define IDM_LINKS                       40013
#define IDM_HELPCONTENTS                40014
#define IDM_HELPSEARCH                  40015
#define IDM_HELPHELP                    40016
#define IDM_ABOUT                       40017
#define ID_AUDIO_BEGIN                  40018
#define ID_AUDIO_PAUSE                  40020
#define ID_AUDIO_OPEN                   40021
#define ID_AUDIO_CLOSE                  40022
#define ID_WINDOWS_CREATECHILDREN       40023
#define ID_WINDOWS_DESTROYBATCHOFCHILDREN 40024
#define ID_AUDIO_OPEN_FILE              40025
#define ID_AUDIO_OPEN_URL               40026
#define ID_AUDIO_ENABLEVOLUMEFADE       40027
#define STATUS_WRITE                    40028
#define RA_MESSAGE                      40029
#define ID_AUDIO_OPEN_HTTP              40030
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40031
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
