/////////////////////////////////////////////////////////////////////////////
//
//      DO_RA.CPP
//
//      Implements calls to low-level ra32.dll
//		Also implements file opne and URL open dialog boxes so gen16.c
//		can be a cleaner UI interface. 
//
//      Bridie Saccocio           5/20/96
//      Adam Schaeffer
//
//      Copyright �1995,1996 Progressive Networks, Inc.  All rights reserved.
//
//

#include <windows.h> 

#include "ra.h"
#include "pnerrors.h"
#include "pntypes.h"
#include "pnnotify.h"

#include "do_ra32.h"
#include "resrc4.h"

#include "string.h"

#ifndef _WIN32
#include <commdlg.h>
#include <toolhelp.h>
#endif


 // Declared in gen16.c:
extern "C"
{   	
	extern HINSTANCE hInst;
	     
	extern BOOL g_VolumeFade;
	extern char g_RaTitle[256];
	extern char g_RaAuthor[256];
	extern char g_RaCopyright[256];
	extern char g_RaPosition[256];
	extern char g_RaStatus[256];
}

//extern void PNEXPORT RaCallbackProc(void*);

// Keep the session handle and http object Id globals:
RaSessionId  g_hRa     = 0; 
RaHttpId     g_HttpID  = NULL;

char g_RaString[MAX_PATH];

BOOL g_HasVolume;

void RA_DoDisplayError (PN_ERROR sError)
{                                      
	// If something is wrong, let's give the error number
	// and use RA16.DLL's built in function for a text
	// printout of the error message
	
	if (sError > PN_NO_ERROR && sError != PN_NOT_NOTIFIED)
	{
		char theMessage[256];                                          
		
		wsprintf(theMessage, "Error #%d - %s", sError, RaGetErrorText(sError) );
		
		MessageBox(NULL, theMessage, "RealAudio Error Message", MB_OK);
	}
}


void RA_DoInit (HWND hWnd) 
{
  	RaInitParams InitParams;    
  	
	// Might want to check RaVersion() before setup....
	InitParams.hInst = hInst; 
	RA_DoDisplayError( RaSetup(&InitParams, &g_hRa, 0) );
    
    // tell windows we want to receive RA notifications
    RaRegisterNotifyWnd(g_hRa, hWnd, RA_MESSAGE, RANTFY_ALL);
    
    // this could be used to establish a separate callback function
    // instead of using the main windows message handler
    
    //RA_DoDisplayError(RaRegisterNotifyCallback(g_hRa, 
    //										   (RANOTIFYPROC)RaCallbackProc,
    //										   RANTFY_ALL));

	// Set language locale...	
	RA_DoDisplayError( RaSetClientLocale(g_hRa, 0) );

	// Client ID String for Server log files.... 
	const char* AppName 		= "Gen32";
	const char* AppVersion 		= "1.0";
	const char* AppLang 		= "EN";
	const char* AppDistCode 	= "Prognet";
	
	char szIDBuffer[256];
	
	RaFormClientIdString(szIDBuffer, 256, AppName,
							AppVersion, AppLang, AppDistCode);
	
	RA_DoDisplayError( RaSetClientId(g_hRa,szIDBuffer) );

	// Set volume range to 1-100...
	if (RaVolumeSupport(g_hRa,100)) {
		g_HasVolume = TRUE;
	} else {
		g_HasVolume = FALSE;
    }
} 


void RA_DoClipAttributes ()
{        
	if (g_hRa)
	{
		// get some clip info
		RaGetClipAttribute(g_hRa, Title, g_RaTitle, 256);
		RaGetClipAttribute(g_hRa, Author, g_RaAuthor, 256);	
		RaGetClipAttribute(g_hRa, Copyright, g_RaCopyright, 256);
		
		// and tell the app it needs to repaint
		HWND hWnd = GetActiveWindow();
		RECT r;
		
		GetClientRect(hWnd, &r);
		InvalidateRect(hWnd, &r, FALSE);
		UpdateWindow(hWnd);
	}
} 


void RA_DoShutDown ()
{
	// Terminate Session...
	RaShutdown(g_hRa);
	g_hRa = NULL;
}


void RA_DoBegin() 
{
	// after we've opened a clip, let's try to play it.
	if (g_hRa) {
		RaBegin(g_hRa);
		//RA_DoDisplayError( RaBegin(g_hRa) );
		
	} else {
		MessageBox(NULL, "No Valid Instance!", "ERROR", MB_OK);
	}
	
	if (g_VolumeFade && g_HasVolume) {
		// set up the timer to change the volume: 20ms interval
		SetTimer(GetActiveWindow(), 1, 20, NULL);        
	}	
}


void RA_DoPause() 
{
	// pause the clip
	RaPause(g_hRa);
}


void RA_DoClose()
{
	// close the current clip
	RaClose(g_hRa);
}

BOOL RA_DoCloseHttp()
{
	// close the current HTTP connection
	if (g_HttpID)
	{
		RaCloseHttp(g_hRa, g_HttpID);
		g_HttpID = NULL;
		return TRUE;
	}
	return FALSE;
}

int RA_DoGetVolume() 
{
	// what is the current volume?
	UINT16 volume;
	RaGetVolume(g_hRa, &volume);   
	return volume;
}

void RA_DoSetVolume(int newVolume) 
{
	// set a new volume (on a scale from 0 to whatever we set as a
	// maximum in RaVolumeSupport() )
	RaSetVolume(g_hRa, (UINT16)newVolume);
}

void RA_DoOpenLocal() 
{
		//Use a common dialog to select a .RA file and play it.

		char filters[] = "RA Files (*.ra)\0*.ra\0\0";
		char fileName[MAX_PATH];
		OPENFILENAME  ofn;

		lstrcpy(fileName,"c:\\raplayer\\thankyou.ra");

		ofn.lStructSize = sizeof(ofn);
		ofn.hwndOwner = GetActiveWindow();
		ofn.hInstance = hInst;
		ofn.lpstrFilter = filters;
		ofn.lpstrCustomFilter = NULL;
		ofn.nMaxCustFilter = 0;
		ofn.nFilterIndex = 1;
		ofn.lpstrFile = fileName;
		ofn.nMaxFile = sizeof(fileName) - 1;
		ofn.lpstrFileTitle = NULL;
		ofn.nMaxFileTitle = 0;
		ofn.lpstrInitialDir = NULL;
		ofn.lpstrTitle = "Real Audio File";
		ofn.Flags = OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
		ofn.nFileOffset = 0;
		ofn.nFileExtension = 0;
		ofn.lpstrDefExt = NULL;
		ofn.lCustData = 0;
		ofn.lpfnHook = NULL;
		ofn.lpTemplateName = NULL;
		
		if (GetOpenFileName(&ofn))
		{
			RA_DoDisplayError( RaOpen(g_hRa, NULL, fileName, 1, FALSE) );
		    RA_DoDisplayError( RaBegin(g_hRa) );
		}
}        


void RA_DoOpenURL() 
{
    // use a dialog box to get a url to open
	
	FARPROC lpProcDlg;  // pointer to the dialog function

	lpProcDlg = MakeProcInstance((FARPROC)OpenURLDlg, hInst);

	DialogBox(hInst,           				// current instance
	        MAKEINTRESOURCE(IDD_OPEN_URL), 	// dlg resource to use
	        GetActiveWindow(),              // parent handle
	        (DLGPROC)lpProcDlg); 			// About() instance address
 
 	FreeProcInstance(lpProcDlg);
}


LRESULT CALLBACK OpenURLDlg(
                HWND hDlg,           // window handle of the dialog box
                UINT message,        // type of message
                WPARAM uParam,       // message-specific information
                LPARAM lParam)
{
        char    szResource[256] = "pnm://audio.realaudio.com/welcome.ra";

        switch (message) {
                case WM_INITDIALOG:  // message: initialize dialog box
                       
                        SetDlgItemText(hDlg, IDC_RESOURCE, szResource);

                        return (TRUE);

                case WM_COMMAND:                      		// message: received a command
                        if (LOWORD(uParam) == IDOK        	// "OK" box selected?
                        || LOWORD(uParam) == IDCANCEL) {  	// System menu close command?
							if (LOWORD(uParam) == IDOK) {

		                        GetDlgItemText(hDlg, IDC_RESOURCE, szResource, sizeof(szResource));

 					 			RA_DoOpenResource(szResource);
 					 			
							}
                            EndDialog(hDlg, TRUE);        	// Exit the dialog
                                                        
                            return (TRUE);
                        }
                        break;
        }
        return (FALSE); // Didn't process the message

        lParam; // This will prevent 'unused formal parameter' warnings
}


void RA_DoOpenHTTP() 
{
    //  this also gets a url, but in a roundabout way.  The URL is received via
    //  HTTP, and then when the HTTP_DONE Sub-Notification Code callback is made
    //  we'll be able to open that url.
     
	FARPROC lpProcDlg;  // pointer to the dialog function

	lpProcDlg = MakeProcInstance((FARPROC)OpenHTTPDlg, hInst);

	DialogBox(hInst,           					// current instance
	        MAKEINTRESOURCE(IDD_OPEN_HTTP), 	// dlg resource to use
	        GetActiveWindow(),              	// parent handle
	        (DLGPROC)lpProcDlg); 				// About() instance address
 
 	FreeProcInstance(lpProcDlg);
}


LRESULT CALLBACK OpenHTTPDlg(
                HWND hDlg,           // window handle of the dialog box
                UINT message,        // type of message
                WPARAM uParam,       // message-specific information
                LPARAM lParam)
{
        char    szResource[256] = "http://www.realaudio.com/products/tools/sdk/welcome.ram";

        switch (message) {
                case WM_INITDIALOG:  // message: initialize dialog box
                                 
                        SetDlgItemText(hDlg, IDC_RESOURCE, szResource);

                        return (TRUE);

                case WM_COMMAND:                      		// message: received a command
                        if (LOWORD(uParam) == IDOK        	// "OK" box selected?
                        || LOWORD(uParam) == IDCANCEL) {  	// System menu close command?
							if (LOWORD(uParam) == IDOK) {

		                        GetDlgItemText(hDlg, IDC_RESOURCE, szResource, sizeof(szResource));

 					 			RA_DoDisplayError( RaOpenHttp(g_hRa, szResource, &g_HttpID) );
 					 			if (! g_HttpID)
 					 				MessageBox(NULL, "Invalid g_HttpID", NULL, MB_OK);
 					 			
							}
                            EndDialog(hDlg, TRUE);        	// Exit the dialog
                            
                            return (TRUE);
                        }
                        break;
        }
        return (FALSE); // Didn't process the message

        lParam; // This will prevent 'unused formal parameter' warnings
}


void RA_DoOpenResource(char *s)
{
	// we can call this from two places:  after we get the URL from 
	// the HTTP callback, and after we get a URL from the openURL
	// dialog box.
	
	if (g_hRa)
	{
		RA_DoDisplayError( RaOpenURL(g_hRa, s) );
		RA_DoDisplayError( RaBegin(g_hRa) );
	}	
}

