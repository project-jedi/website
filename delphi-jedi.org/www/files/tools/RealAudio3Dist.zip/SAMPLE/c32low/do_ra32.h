/////////////////////////////////////////////////////////////////////////////
//
//      DO_RA.H
//
//      function definitions for do_ra.cpp 
//
//      Bridie Saccocio           5/20/96
//
//      Copyright �1995,1996 Progressive Networks, Inc.  All rights reserved.
//
//

#ifdef __cplusplus
extern "C" {
#endif	
	extern void RA_DoInit(HWND hWnd);
	extern void RA_DoShutDown();
	extern void RA_DoOpenLocal();
	extern void RA_DoOpenURL();
	extern void RA_DoOpenHTTP();
	extern void RA_DoOpenResource(char*);
	extern void RA_DoClipAttributes();
	extern void RA_DoBegin();
	extern void RA_DoPause();
	extern void RA_DoClose();
	extern BOOL RA_DoCloseHttp();   
	extern int  RA_DoGetVolume();  
	extern void RA_DoSetVolume(int v);  
#ifdef __cplusplus
}
#endif


LRESULT CALLBACK OpenURLDlg(
                HWND hDlg,           // window handle of the dialog box
                UINT message,        // type of message
                WPARAM uParam,       // message-specific information
                LPARAM lParam);

LRESULT CALLBACK OpenHTTPDlg(
                HWND hDlg,           // window handle of the dialog box
                UINT message,        // type of message
                WPARAM uParam,       // message-specific information
                LPARAM lParam);
