/////////////////////////////////////////////////////////////////////////////
//
//      GEN32.C
//
//      Implements UI for RealAudio 32-bit SDK sample.  This code is largely
//		based on Generic.c, available as sample code with MS Visual C/C++
//
//		Its purpose is to illustrate how to invoke and interact with the
//		low-level ra32.dll.   
//
//      Bridie Saccocio           5/20/96
//      Adam Schaeffer			 
//
//      Copyright �1995,1996 Progressive Networks, Inc.  All rights reserved.
//
//


#include <windows.h>   // required for all Windows applications  
#include <string.h>
#include "resrc4.h"    // Windows resource IDs
#include "gen32.h"     // specific to this program
#include <commdlg.h>   // specific to this program

#include "do_ra32.h"
#include "pntypes.h"
#include "pnnotify.h"
#include "ra.h"		   // for sizeof(HttpID)

#ifdef _WIN32
	#include <winver.h>
#else
	#include <ver.h>
#endif

extern HINSTANCE hInst       		= NULL;          // current instance
extern BOOL 	 g_VolumeFade    	= FALSE;

	// some info strings
extern char 	g_RaTitle[256]     	= "UNKNOWN";
extern char 	g_RaAuthor[256]   	= "UNKNOWN";
extern char 	g_RaCopyright[256]	= "UNKNOWN";
extern char 	g_RaPosition[256] 	= "n/a";
extern char 	g_RaStatus[256] 	= "Ready.";

char szAppName[]    = "Gen32";   // The name of this application
char szTitle[]      = "32-bit MSVC RealAudio� SDK Sample App"; // The title bar text


ULONG32	CurItemPos;
ULONG32 CurItemLen;

/****************************************************************************

        FUNCTION: WinMain(HINSTANCE, HINSTANCE, LPSTR, int)

        PURPOSE: calls initialization function, processes message loop

        COMMENTS:

                Windows recognizes this function by name as the initial entry point
                for the program.  This function calls the application initialization
                routine, if no other instance of the program is running, and always
                calls the instance initialization routine.  It then executes a message
                retrieval and dispatch loop that is the top-level control structure
                for the remainder of execution.  The loop is terminated when a WM_QUIT
                message is received, at which time this function exits the application
                instance by returning the value passed by PostQuitMessage().

                If this function must abort before entering the message loop, it
                returns the conventional value NULL.

****************************************************************************/
int CALLBACK WinMain(
        HINSTANCE hInstance,
        HINSTANCE hPrevInstance,
        LPSTR lpCmdLine,
        int nCmdShow)
{

        MSG msg;
        HANDLE hAccelTable;

        if (!hPrevInstance) {       // Other instances of app running?
                        if (!InitApplication(hInstance)) { // Initialize shared things
                        return (FALSE);     // Exits if unable to initialize
                }
        }

        /* Perform initializations that apply to a specific instance */

        if (!InitInstance(hInstance, nCmdShow)) {
                return (FALSE);
        }

        hAccelTable = LoadAccelerators (hInstance, MAKEINTRESOURCE(IDR_GENERIC));


        /* Acquire and dispatch messages until a WM_QUIT message is received. */

		while (GetMessage(&msg,NULL,0,0))
		{
			if (!TranslateAccelerator (msg.hwnd, hAccelTable, &msg))
			{
				TranslateMessage(&msg);// Translates virtual key codes
				DispatchMessage(&msg); // Dispatches message to window
			}
		}

        return (msg.wParam); // Returns the value from PostQuitMessage

        lpCmdLine; // This will prevent 'unused formal parameter' warnings
}


/****************************************************************************

        FUNCTION: InitApplication(HINSTANCE)

        PURPOSE: Initializes window data and registers window class

        COMMENTS:

                This function is called at initialization time only if no other
                instances of the application are running.  This function performs
                initialization tasks that can be done once for any number of running
                instances.

                In this case, we initialize a window class by filling out a data
                structure of type WNDCLASS and calling the Windows RegisterClass()
                function.  Since all instances of this application use the same window
                class, we only need to do this when the first instance is initialized.


****************************************************************************/

BOOL InitApplication(HINSTANCE hInstance)
{
        WNDCLASS  wc;

        // Fill in window class structure with parameters that describe the
        // main window.

        wc.style         = CS_HREDRAW | CS_VREDRAW;// Class style(s).
        wc.lpfnWndProc   = (WNDPROC)WndProc;       // Window Procedure
        wc.cbClsExtra    = 0;                      // No per-class extra data.
        wc.cbWndExtra    = 0;                      // No per-window extra data.
        wc.hInstance     = hInstance;              // Owner of this class
        wc.hIcon         = LoadIcon (hInstance, MAKEINTRESOURCE(IDI_APP)); // Icon name from .RC
        wc.hCursor       = LoadCursor(NULL, IDC_ARROW);// Cursor
        wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);// Default color
        wc.lpszMenuName  = MAKEINTRESOURCE(IDR_GENERIC); // Menu from .RC
        wc.lpszClassName = szAppName;              // Name to register as

        // Register the window class and return success/failure code.
        return (RegisterClass(&wc));
}


/****************************************************************************

        FUNCTION:  InitInstance(HINSTANCE, int)

        PURPOSE:  Saves instance handle and creates main window

        COMMENTS:

                This function is called at initialization time for every instance of
                this application.  This function performs initialization tasks that
                cannot be shared by multiple instances.

                In this case, we save the instance handle in a static variable and
                create and display the main program window.

****************************************************************************/

BOOL InitInstance(
        HINSTANCE          hInstance,
        int             nCmdShow)
{
        HWND            hWnd; // Main window handle.

        // Save the instance handle in static variable, which will be used in
        // many subsequence calls from this application to Windows.

        hInst = hInstance; // Store instance handle in our global variable

        // Create a main window for this application instance.

        hWnd = CreateWindow(
                szAppName,           			// See RegisterClass() call.
                szTitle,             			// Text for window title bar.
                WS_OVERLAPPEDWINDOW,			// Window style.
                CW_USEDEFAULT, CW_USEDEFAULT,  	// Use default positioning
                530, 230,                       // Desired size of window
                NULL,                			// Overlapped windows have no parent.
                NULL,                			// Use the window class menu.
                hInstance,           			// This instance owns this window.
                NULL                 			// We don't use any data in our WM_CREATE
        );

        // If window could not be created, return "failure"
        if (!hWnd) {
                return (FALSE);
        }


        // Make the window visible; update its client area; and return "success"
        ShowWindow(hWnd, nCmdShow); // Show the window
        UpdateWindow(hWnd);         // Sends WM_PAINT message

        return (TRUE);              // We succeeded...

}

/****************************************************************************

        FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)

        PURPOSE:  Processes messages

        MESSAGES:

        WM_COMMAND    - application menu (About dialog box)
        WM_DESTROY    - destroy window

        COMMENTS:

        To process the IDM_ABOUT message, call MakeProcInstance() to get the
        current instance address of the About() function.  Then call Dialog
        box which will create the box according to the information in your
        generic.rc file and turn control over to the About() function.  When
        it returns, free the intance address.

****************************************************************************/

LRESULT CALLBACK WndProc(
                HWND hWnd,         // window handle
                UINT message,      // type of message
                WPARAM uParam,     // additional information
                LPARAM lParam)     // additional information
{
	FARPROC lpProcAbout;  // pointer to the "About" function
	unsigned int wmId, wmEvent;
	
	// to assist in the volume fade
    static BOOL   FirstTimer = TRUE; 
    static int 	  MaxVolume;
    static int    NewVolume;

    PAINTSTRUCT   ps;
    
    NotificationDataPacket* pNotifyPacket;

	ULONG32		NotifyCode;
	ULONG32		NotifySubCode;
	ULONG32		UserDataSize;
	UCHAR*		pUserData;
    
    ULONG32		CurItemPos;
    ULONG32		CurItemLen;
    
    //static      BOOL been       = FALSE;
    HDC			hDC;
    HPEN		hPen, oldPen;
    
	switch (message) {
		case WM_CREATE:
			RA_DoInit(hWnd);
			break;
			
	    case WM_COMMAND:  // message: command from application menu

	        wmId    = LOWORD(uParam);
	        wmEvent = HIWORD(uParam);

	        switch (wmId) {
	            case IDM_ABOUT:
	                    lpProcAbout = MakeProcInstance((FARPROC)About, hInst);

	                    DialogBox(hInst,           // current instance
	                            MAKEINTRESOURCE(IDD_ABOUTBOX), // dlg resource to use
	                            hWnd,                  // parent handle
	                            (DLGPROC)lpProcAbout); // About() instance address

	                    FreeProcInstance(lpProcAbout);
	                    break;

	            case IDM_EXIT:
	                    DestroyWindow (hWnd);
	                    break;

	            case IDM_HELPCONTENTS:
	                    if (!WinHelp (hWnd, "GENERIC.HLP", HELP_KEY,(DWORD)(LPSTR)"CONTENTS")) {
	                            MessageBox (GetFocus(),
	                                    "Unable to activate help",
	                                    szAppName, MB_SYSTEMMODAL|MB_OK|MB_ICONHAND);
	                    }
	                    break;

	            case IDM_HELPSEARCH:
	                    if (!WinHelp(hWnd, "GENERIC.HLP", HELP_PARTIALKEY, (DWORD)(LPSTR)"")) {
	                            MessageBox (GetFocus(),
	                                    "Unable to activate help",
	                                    szAppName, MB_SYSTEMMODAL|MB_OK|MB_ICONHAND);
	                    }
	                    break;

	            case IDM_HELPHELP:
	                    if(!WinHelp(hWnd, (LPSTR)NULL, HELP_HELPONHELP, 0)) {
	                            MessageBox (GetFocus(),
	                                    "Unable to activate help",
	                                    szAppName, MB_SYSTEMMODAL|MB_OK|MB_ICONHAND);
	                    }
	                    break;


		        case ID_AUDIO_OPEN_FILE:
				{
					RA_DoOpenLocal();
				}
				break;

		        case ID_AUDIO_OPEN_URL:
				{
					RA_DoOpenURL();
				}
				break; 
				
				case ID_AUDIO_OPEN_HTTP:
				{
					RA_DoOpenHTTP();
				}
				break;

		        case ID_AUDIO_BEGIN:
				{
					RA_DoBegin();
				}
				break;

		        case ID_AUDIO_PAUSE:
				{
					RA_DoPause();
				}
				break;

		        case ID_AUDIO_CLOSE:
				{
					RA_DoClose();
				}
				break;   
				
				case ID_AUDIO_ENABLEVOLUMEFADE:
				{
					HMENU TheMenu;
					TheMenu = GetMenu(hWnd); 

					if (g_VolumeFade) {
						g_VolumeFade = FALSE;
						CheckMenuItem(TheMenu,
									  (UINT) ID_AUDIO_ENABLEVOLUMEFADE,
									  MF_UNCHECKED);
					} else {
						g_VolumeFade = TRUE; 
						CheckMenuItem(TheMenu,
									  (UINT) ID_AUDIO_ENABLEVOLUMEFADE,
									  MF_CHECKED);
					}
				}
				break;

	            // Here are all the other possible menu options,
	            // all of these are currently disabled:
	            case IDM_NEW:
	            case IDM_SAVE:
	            case IDM_SAVEAS:
	            case IDM_UNDO:
	            case IDM_CUT:
	            case IDM_COPY:
	            case IDM_PASTE:
	            case IDM_LINK:
	            case IDM_LINKS:

	            default:
	                return (DefWindowProc(hWnd, message, uParam, lParam));
	        }
	        break; 
	        
	    case WM_TIMER:  // message: timer timeout (for volume fade in)
				
				//  the idea here is to find out what value the volume is
				//  currently set to and then fade up to it from zero
				if (FirstTimer) {
					FirstTimer = FALSE;
					NewVolume = 0;
					MaxVolume = RA_DoGetVolume(); 
					RA_DoSetVolume(NewVolume);
				} else {
					NewVolume += 1;
					if (NewVolume > MaxVolume) {
						KillTimer(GetActiveWindow(), 1);
						FirstTimer = TRUE;
					} else {
						RA_DoSetVolume(NewVolume);
					}
				}
	      
	            break;   
        
        case WM_PAINT:	//show what clip info we know
        
        		// and display it			
				BeginPaint(hWnd, (LPPAINTSTRUCT) &ps);

				Rectangle(ps.hdc, 15, 15, 500, 80);

				TextOut(ps.hdc, 20, 20, "Title:", 6);
				TextOut(ps.hdc, 90, 20, g_RaTitle, strlen(g_RaTitle) );

				TextOut(ps.hdc, 20, 40, "Author:", 7);
				TextOut(ps.hdc, 90, 40, g_RaAuthor, strlen(g_RaAuthor) );

				TextOut(ps.hdc, 20, 60, "Copyright:", 10);
				TextOut(ps.hdc, 90, 60, g_RaCopyright, strlen(g_RaCopyright) );
		        
		        Rectangle(ps.hdc, 15, 97, 500, 120);
		        TextOut(ps.hdc, 20, 100, "Status:", 7);
				TextOut(ps.hdc, 90, 100, g_RaStatus, strlen(g_RaStatus) );
				
				Rectangle(ps.hdc, 15, 122, 500, 145);
				TextOut(ps.hdc, 20, 125, "Position:", 9);  
				TextOut(ps.hdc, 90, 125, g_RaPosition, strlen(g_RaPosition) );
				
				EndPaint(hWnd, (LPPAINTSTRUCT) &ps);     
				break;
	    
	    case WM_DESTROY:  // message: window being destroyed
				RA_DoClose();
				RA_DoShutDown();
				PostQuitMessage(0);
	            break;

	
		case RA_MESSAGE:
	    		// this message handler can also be set up as a separate callback function
	    		
	    		// the "lParam" pointer points to a pNotifyPacket structure
				pNotifyPacket 	= (NotificationDataPacket*)lParam;
				NotifyCode		= pNotifyPacket->NotifyCode;
				NotifySubCode	= pNotifyPacket->NotifySubCode;
				UserDataSize	= pNotifyPacket->UserDataSize;
				pUserData		= (UCHAR*)pNotifyPacket + sizeof(NotificationDataPacket);
				
				//  We'll want to do some quick text drawing
	            hDC = GetDC(hWnd);
	
				hPen = CreatePen(PS_SOLID, 1, RGB(255,255,255));
				oldPen = SelectObject(hDC, hPen);
		
				//  parse the notification code
				switch(NotifyCode)
				{
					case RANTFY_POSITION:
					{
						CurItemPos = *((ULONG32*)&pUserData[0]);
						CurItemLen = *((ULONG32*)&pUserData[4]);
			
						wsprintf(g_RaPosition, "( %lu / %lu )      ", CurItemPos, CurItemLen);
						TextOut(hDC, 90, 125, g_RaPosition, strlen(g_RaPosition) );
					}
					break;

					case RANTFY_PLAY_STATUS:
					{
						const char* pMessage = (const char*)pUserData;
						switch(NotifySubCode)
						{
							case RASUBNTFY_CONTACTING_HOST:
							{
								// clear the 'Status bar'
								Rectangle(hDC, 90, 98, 499, 119);
								TextOut(hDC, 90, 100, pMessage, strlen(pMessage) );
							}
							break;

							case RASUBNTFY_BUFFERING:
							{
								// show the title, author, copyright info
								RA_DoClipAttributes();                   
					
								// clear the 'Status bar'
								Rectangle(hDC, 90, 98, 499, 119);
								TextOut(hDC, 90, 100, pMessage, strlen(pMessage) );
							}
							break;

							case RASUBNTFY_AUDIO_STARTED:
							{
								// clear the 'Status bar'
								Rectangle(hDC, 90, 98, 499, 119);
								TextOut(hDC, 90, 100, pMessage, strlen(pMessage) );
								strcpy(g_RaStatus, pMessage);
							}
							break;

							case RASUBNTFY_PLAYBACK_STOPPED:
							{
								// clear the 'Status bar' and close the clip
								Rectangle(hDC, 90, 98, 499, 119);
								TextOut(hDC, 90, 100, pMessage, strlen(pMessage) );
								RA_DoClose();
							}
							break;
						}
					}
					break;
		
					case RANTFY_CLOSED:
					{
						// clear the 'Status bar'
						Rectangle(hDC, 90, 98, 499, 119);
						TextOut(hDC, 90, 100, "Stopped.", 8 );
					}
					break;
		
					case RANTFY_HTTP:
					{
						const char* pMessage = (const char*)pUserData;
						switch(NotifySubCode)
						{
							case RASUBNTFY_HTTP_STATUS:
							{
							
							}
							break;
				
							case RASUBNTFY_HTTP_DONE:
							{
								char URL[256];
			                    								
								// now that we've gotten the url, we need to close the HTTP connection
								if ( RA_DoCloseHttp() )
								{
									// the last 5 characters of pMessage are a newline followed by the HttpID.
									// Theoretically one could have more than one http connection open, and then
									// you can use the RaHttpId here to close the right one.
									memset(URL, 0, 256);
									strncpy(URL, pMessage, (int)UserDataSize - (sizeof(RaHttpId) + 1));
											
									// and finally, open & play the url.
									RA_DoOpenResource(URL);			
								}
							}
							break;
						}
					}
					break;
				}
				
				// release our resources now that we're done
				SelectObject(hDC, oldPen);
				DeleteObject(hPen);
				
				ReleaseDC(hWnd, hDC);
				break;
	    
	    default:          // Passes it on if unproccessed
	            return (DefWindowProc(hWnd, message, uParam, lParam));
	}
	return (0);
}

/****************************************************************************

        FUNCTION: CenterWindow (HWND, HWND)

        PURPOSE:  Center one window over another

        COMMENTS:

        Dialog boxes take on the screen position that they were designed at,
        which is not always appropriate. Centering the dialog over a particular
        window usually results in a better position.

****************************************************************************/

BOOL CenterWindow (HWND hwndChild, HWND hwndParent)
{
        RECT    rChild, rParent;
        int     wChild, hChild, wParent, hParent;
        int     wScreen, hScreen, xNew, yNew;
        HDC     hdc;

        // Get the Height and Width of the child window
        GetWindowRect (hwndChild, &rChild);
        wChild = rChild.right - rChild.left;
        hChild = rChild.bottom - rChild.top;

        // Get the Height and Width of the parent window
        GetWindowRect (hwndParent, &rParent);
        wParent = rParent.right - rParent.left;
        hParent = rParent.bottom - rParent.top;

        // Get the display limits
        hdc = GetDC (hwndChild);
        wScreen = GetDeviceCaps (hdc, HORZRES);
        hScreen = GetDeviceCaps (hdc, VERTRES);
        ReleaseDC (hwndChild, hdc);

        // Calculate new X position, then adjust for screen
        xNew = rParent.left + ((wParent - wChild) /2);
        if (xNew < 0) {
                xNew = 0;
        } else if ((xNew+wChild) > wScreen) {
                xNew = wScreen - wChild;
        }

        // Calculate new Y position, then adjust for screen
        yNew = rParent.top  + ((hParent - hChild) /2);
        if (yNew < 0) {
                yNew = 0;
        } else if ((yNew+hChild) > hScreen) {
                yNew = hScreen - hChild;
        }

        // Set it, and return
        return SetWindowPos (hwndChild, NULL,
                xNew, yNew, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
}


/****************************************************************************

        FUNCTION: About(HWND, UINT, WPARAM, LPARAM)

        PURPOSE:  Processes messages for "About" dialog box

        MESSAGES:

        WM_INITDIALOG - initialize dialog box
        WM_COMMAND    - Input received

        COMMENTS:

        Display version information from the version section of the
        application resource.

        Wait for user to click on "Ok" button, then close the dialog box.

****************************************************************************/
LRESULT CALLBACK About(
                HWND hDlg,           // window handle of the dialog box
                UINT message,        // type of message
                WPARAM uParam,       // message-specific information
                LPARAM lParam)
{
        static  HFONT hfontDlg;
        LPSTR   lpVersion;
        DWORD   dwVerInfoSize;
        DWORD   dwVerHnd;
        UINT    uVersionLen;
        WORD    wRootLen;
        BOOL    bRetCode;
        int     i;
        char    szFullPath[256];
        char    szResult[256];
        char    szGetName[256];

        switch (message) {
                case WM_INITDIALOG:  // message: initialize dialog box
                        // Center the dialog over the application window
                        CenterWindow (hDlg, GetWindow (hDlg, GW_OWNER));

                        // Get version information from the application
                        GetModuleFileName (hInst, szFullPath, sizeof(szFullPath));
                        dwVerInfoSize = GetFileVersionInfoSize(szFullPath, &dwVerHnd);
                        if (dwVerInfoSize) {
                                // If we were able to get the information, process it:
                                LPSTR   lpstrVffInfo;
                                HANDLE  hMem;
                                hMem = GlobalAlloc(GMEM_MOVEABLE, dwVerInfoSize);
                                lpstrVffInfo  = GlobalLock(hMem);
                                GetFileVersionInfo(szFullPath, dwVerHnd, dwVerInfoSize, lpstrVffInfo);
                                lstrcpy(szGetName, "\\StringFileInfo\\040904e4\\");
                                wRootLen = lstrlen(szGetName);

                                // Walk through the dialog items that we want to replace:
                                for (i = IDC_FILEDESCRIPTION; i <= IDC_LEGALTRADEMARKS; i++) {
                                        GetDlgItemText(hDlg, i, szResult, sizeof(szResult));
                                        szGetName[wRootLen] = (char)0;
                                        lstrcat (szGetName, szResult);
                                        uVersionLen   = 0;
                                        lpVersion     = NULL;
                                        bRetCode      =  VerQueryValue((LPVOID)lpstrVffInfo,
                                                		(LPSTR)szGetName,
                                                		(LPVOID)&lpVersion,
                                                		(LPDWORD)&uVersionLen); // For MIPS strictness

                                        if ( bRetCode && uVersionLen && lpVersion) {
                                                // Replace dialog item text with version info
                                                lstrcpy(szResult, lpVersion);
                                                SetDlgItemText(hDlg, i, szResult);
                                        }
                                }

                                GlobalUnlock(hMem);
                                GlobalFree(hMem);
                        } 
                        // Create a font to use
                        hfontDlg = CreateFont(12, 0, 0, 0, 0, 0, 0, 0,
                                0, 0, 0, 0, 0, "MS Sans Serif");

                        // Walk through the dialog items and change font
                        for (i = IDC_FILEDESCRIPTION; i <= IDC_LEGALTRADEMARKS; i++)
							SendMessage (GetDlgItem (hDlg, i), WM_SETFONT, (UINT)hfontDlg, TRUE);

                        return (TRUE);

                case WM_COMMAND:                      // message: received a command
                        if (LOWORD(uParam) == IDOK        // "OK" box selected?
                        || LOWORD(uParam) == IDCANCEL) {  // System menu close command?
                                EndDialog(hDlg, TRUE);        // Exit the dialog
                                DeleteObject (hfontDlg);
                                return (TRUE);
                        }
                        break;
        }
        return (FALSE); // Didn't process the message

        lParam; // This will prevent 'unused formal parameter' warnings
}

