/////////////////////////////////////////////////////////////////////////////
//
//	VB_RAENC.H
//
//	Defines the VB public interface to RA_ENC.DLL, the RealAudio low level
//	encoder application inteface library.  This interface can be included
//  by C or C++ code but is designed specifically to allow VB style
//  environments to interact with RealAudio functions which take pointers
//  to structures, strings, and arrays.  Because VB cannot change it's struct
//	byte alignment, it cannot interact directly with some RA functions.
//
// Adam D. Schaeffer		10/96
//
// Copyright(C) Progressive Networks, inc.
// All Rights Reserved.
//


#if !defined(VB_RAENC_H)
#define VB_RAENC_H

#include "pntypes.h"
#include "racodec.h"
#include "enexport.h"

#define CCONV	 _stdcall
#define NOMANGLE

#define ENEXPORT __declspec(dllexport) FAR PASCAL

#if defined(__cplusplus)
// Windows wants DLL exports to have 'C' naming
extern "C" {
#endif

/////////////////////////////////////////////////////////////////////////////
//
//	Macro:
//
//		VB_RAenc_GetMajorVersion()
//
//	Purpose:
//
//		Returns the Major version portion of the encoded product version 
//		of the low level application interface library previously returned
//	 	from a call to Raenc_GetProductVersion().
//
//	Parameters:
//
//		prodVer
//		The encoded product version of the RA_ENC.DLL previously returned 
//		from a call to Raenc_GetProductVersion().
//
//	Return:
//
//		The major version number of the RA_ENC.DLL
//
//
NOMANGLE ULONG32 CCONV VB_RAenc_GetMajorVersion(ULONG32 prodVer);

/////////////////////////////////////////////////////////////////////////////
//
//	Macro:
//
//		VB_RAenc_GetMinorVersion()
//
//	Purpose:
//
//		Returns the minor version portion of the encoded product version 
//		of the low level application interface library previously returned
//	 	from a call to Raenc_GetProductVersion().
//
//	Parameters:
//
//		prodVer
//		The encoded product version of the RA_ENC.DLL previously returned 
//		from a call to Raenc_GetProductVersion().
//
//	Return:
//
//		The minor version number of the RA_ENC.DLL
//
//
NOMANGLE ULONG32 CCONV VB_RAenc_GetMinorVersion(ULONG32 prodVer);

/////////////////////////////////////////////////////////////////////////////
//
//	Macro:
//
//		VB_RAenc_GetReleaseNumber()
//
//	Purpose:
//
//		Returns the release number portion of the encoded product version 
//		of the low level application interface library previously returned
//	 	from a call to Raenc_GetProductVersion().
//
//	Parameters:
//
//		prodVer
//		The encoded product version of the RA_ENC.DLL previously returned 
//		from a call to Raenc_GetProductVersion().
//
//	Return:
//
//		The release number of the RA_ENC.DLL
//
//
NOMANGLE ULONG32 CCONV VB_RAenc_GetReleaseNumber(ULONG32 prodVer);

/////////////////////////////////////////////////////////////////////////////
//
//	Macro:
//
//		VB_RAenc_GetBuildNumber()
//
//	Purpose:
//
//		Returns the build number portion of the encoded product version 
//		of the low level application interface library previously returned
//	 	from a call to Raenc_GetProductVersion().
//
//	Parameters:
//
//		prodVer
//		The encoded product version of the RA_ENC.DLL previously returned 
//		from a call to Raenc_GetProductVersion().
//
//	Return:
//
//		The build number of the RA_ENC.DLL
//
//
NOMANGLE ULONG32 CCONV VB_RAenc_GetBuildNumber(ULONG32 prodVer);

/////////////////////////////////////////////////////////////////////////////
//
//	Function:
//
//		VB_RAenc_GetFlavorPropertyS()
//
//	Purpose:
//
//		Querys the codec about the properties of it's flavors.  See the
//		RAENC_FLAV_PROPERTY enumerated type.
//
//		The buffer returned by this call should NOT be free'd; managment
//		of the flavor property buffers is handled by the SDK
//
//	Parameters:
//
//		RA_Encoder enc
//		PNFlavorHandle flavor
//		RAENC_FLV_PROPERTY	prop
//		BSTR *pbstrOriginal 
//		UINT16 *rtnBufLen 
//
//	Return:
//
//		PN_ERROR
//		Error code indicating the success or failure of the function.
//
NOMANGLE PN_ERROR CCONV VB_RAenc_GetFlavorPropertyS (RA_Encoder enc,
												 PNFlavorHandle flavor,
												 PN_FLV_PROPERTY prop,
												 BSTR *rtnBuf,
												 UINT16 *rtnBufLen);

/////////////////////////////////////////////////////////////////////////////
//
//	Function:
//
//		VB_RAenc_GetFlavorPropertyL()
//
//	Purpose:
//
//		Querys the codec about the properties of it's flavors.  See the
//		RAENC_FLAV_PROPERTY enumerated type.
//
//		The buffer returned by this call should NOT be free'd; managment
//		of the flavor property buffers is handled by the SDK
//
//	Parameters:
//
//		RA_Encoder enc
//		PNFlavorHandle flavor
//		RAENC_FLV_PROPERTY	prop
//		ULONG32 *rtnBuf
//
//	Return:
//
//		PN_ERROR
//		Error code indicating the success or failure of the function.
//
NOMANGLE PN_ERROR CCONV	VB_RAenc_GetFlavorPropertyL (RA_Encoder enc,
												 PNFlavorHandle flavor,
												 PN_FLV_PROPERTY prop,
												 ULONG32* rtnBuf);

/////////////////////////////////////////////////////////////////////////////
//
//	Function:
//
//		VB_RAenc_GetFlavorInputInfo()
//
//	Purpose:
//
//		Querys the codec about the input properties of it's flavors.
//		See the RAENC_FLAV_PROPERTY enumerated type.
//
//	Parameters:
//
//		RA_Encoder enc
//		PNFlavorHandle flavor
//		UINT16*  FormatTag
//		ULONG32* SamplesPerSec
//		UINT16*  BitsPerSample
//		UINT16*  Channels
//
//	Return:
//
//		PN_ERROR
//		Error code indicating the success or failure of the function.
//
NOMANGLE PN_ERROR CCONV	VB_RAenc_GetFlavorInputInfo (RA_Encoder enc,
												 PNFlavorHandle flavor,
												 UINT16*  FormatTag,
												 ULONG32* SamplesPerSec,
												 UINT16*  BitsPerSample,
												 UINT16*  Channels);

/////////////////////////////////////////////////////////////////////////////
//
//	Function:
//
//		VB_RAenc_GetFlavorOutputInfo()
//
//	Purpose:
//
//		Querys the codec about the output properties of it's flavors.
//		See the RAENC_FLAV_PROPERTY enumerated type.
//
//	Parameters:
//
//		RA_Encoder enc
//		PNFlavorHandle flavor
//		UINT16*  FormatTag
//		ULONG32* SamplesPerSec
//		UINT16*  BitsPerSample
//		UINT16*  Channels
//
//	Return:
//
//		PN_ERROR
//		Error code indicating the success or failure of the function.
//
NOMANGLE PN_ERROR CCONV	VB_RAenc_GetFlavorOutputInfo (RA_Encoder enc,
												 PNFlavorHandle flavor,
												 UINT16*  FormatTag,
												 ULONG32* SamplesPerSec,
												 UINT16*  BitsPerSample,
												 UINT16*  Channels);

/////////////////////////////////////////////////////////////////////////////
//
//	Function:
//
//		VB_RAenc_InitializeEncoder()
//
//	Purpose:
//
//		Sets up the encoder with the chosen codec
//
//	Parameters:
//
//		RA_Encoder enc
//		PNFlavorHandle
//		UINT16  FormatTag;
//		ULONG32 SamplesPerSec;
//		UINT16  BitsPerSample;
//		UINT16  Channels;
//
//	Return:
//
//		PN_ERROR
//		Error code indicating the success or failure of the function.
//
NOMANGLE PN_ERROR CCONV VB_RAenc_InitializeEncoder(ULONG32 enc,
											 ULONG32 flavor,
											 UINT16  FormatTag,
											 ULONG32 SamplesPerSec,
											 UINT16  BitsPerSample,
											 UINT16  Channels);

/////////////////////////////////////////////////////////////////////////////
//
//	Function:
//
//		RAenc_SetOutputFile()
//
//	Purpose:
//
//		SetOutputFile() creates an opens a RealAudio .ra file that
//		will received the encoded audio data. Returns PN_NO_ERROR
//		if successful.  This function must be called even if the
//		destination is a server/LTA
//
//	Parameters:
//
//		RA_Encoder enc
//		BSTR *outFile
//
//	Return:
//
//		PN_ERROR
//		Error code indicating the success or failure of the function.
//
NOMANGLE PN_ERROR CCONV VB_RAenc_SetOutputFile(ULONG32 enc, BSTR *outFile);

/////////////////////////////////////////////////////////////////////////////
//
//	Function:
//
//		VB_RAenc_Title()
//
//	Purpose:
//
//		Sets the title of a clip.
//
//	Parameters:
//
//		RA_Encoder  enc
//		const char* Title	
//
//	Return:
//
//		PN_ERROR
//		Error code indicating the success or failure of the function.
//																	  
NOMANGLE void CCONV VB_RAenc_Title(ULONG32 enc, BSTR *pbstrTitle);

/////////////////////////////////////////////////////////////////////////////
//
//	Function:
//
//		VB_RAenc_Author()
//
//	Purpose:
//
//		Sets the title of a clip.
//
//	Parameters:
//
//		RA_Encoder  enc
//		const char* Title	
//
//	Return:
//
//		PN_ERROR
//		Error code indicating the success or failure of the function.
//
NOMANGLE void CCONV VB_RAenc_Author(ULONG32 enc, BSTR *pbstrAuthor);

/////////////////////////////////////////////////////////////////////////////
//
//	Function:
//
//		VB_RAenc_Copyright()
//
//	Purpose:
//
//		Sets the title of a clip.
//
//	Parameters:
//
//		RA_Encoder  enc
//		const char* Title	
//
//	Return:
//
//		PN_ERROR
//		Error code indicating the success or failure of the function.
//																		   
NOMANGLE void CCONV VB_RAenc_Copyright(ULONG32 enc, BSTR *pbstrCopyright);

/////////////////////////////////////////////////////////////////////////////
//
//	Function:
//
//		VB_RAenc_Encode()
//
//	Purpose:
//
//		Called to encode chunks of data to a file.  If "encoding to buffer"
//		is being used, this routine must be called repeatedly with an inLength
//		of 0 until it returns an outLength of 0; this is to guarantee that all
//		the data is encoded and interleaved properly.
//
//		If the SDK is performing sample rate conversion, it is possible that
//		the encoder will occasionally require a different number of bytes to
//		be input than the value returned from GetBufferSizes; this value will
//		be returned in nextEncodeSize.  The next call to RAenc_Encode() must
//		always pass in the number of bytes requested by the previous call to
//		encode.
//
//	Parameters:
//
//		RA_Encoder   enc
//		void		*inBuf
//		ULONG32		 inLength
//		void		*outBuf
//		ULONG32		*outLength
//		double		*timestamp 
//		ULONG32     *nextEncodeSize
//
//	Return:
//
//		PN_ERROR
//		Error code indicating the success or failure of the function.
//
NOMANGLE PN_ERROR CCONV		VB_RAenc_Encode(RA_Encoder	 enc, 
								  LPSAFEARRAY FAR *ppsa, 
								  ULONG32		   inLength,
								  UCHAR			  *outBuf,
								  ULONG32		  *outLength,
								  double		  *timestamp,
							      ULONG32		  *nextEncodeSize);


#if defined(__cplusplus)
}	// close extern "C"
#endif

#endif	//!defined(VB_RAENC_H)

