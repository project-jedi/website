/////////////////////////////////////////////////////////////////////////////
//
//      RaLivEnc.H
//
//  	Header file for RaLivEnc.cpp.  Defines user types and declares
//		functions
//
//      John Burroughs          5/96
//		Adam Schaeffer			7/96
//		Kurt Howard				11/96
//
//		Copyright �1995,1996 Progressive Networks, Inc.
//		All Rights Reserved.
//      

#if !defined(RaLivEnc_H)
#define RaLivEnc_H

#include "pntypes.h"
#include "pnerrors.h"
#include "enexport.h"

#define MAX_CAPTION 1024

typedef struct
{
	char _server	[MAX_PATH];
	char _password	[MAX_PATH];
	char _portnum	[MAX_PATH];

	char _output[MAX_PATH];

	char _title[MAX_CAPTION];
	char _author[MAX_CAPTION];
	char _copyright[MAX_CAPTION];

	int _codec;	   // this is really the codec flavor
	int _sampling; // encoder does rate conversion
	int _pcm;      // 8 or 16

//	BOOL _perfectplay;
	BOOL _selectiverecord;

} ENAPP_OPTIONS;

void DoInit(HWND w);
void DoAbort(void);
void DoEncode(HWND, ENAPP_OPTIONS*);

///////////////////////////////

void RaError(char *);

#endif	//!defined(RaLivEnc_H)
/******************************************/
