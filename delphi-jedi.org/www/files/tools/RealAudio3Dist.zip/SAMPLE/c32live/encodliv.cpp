/////////////////////////////////////////////////////////////////////////////
//
//	Encode.CPP
//
//	Interface with low-level MM audio and Real Audio 3.0 Encoder API
//
//	John Burroughs		5/96
//	Adam Schaeffer		7/96
//	Kurt Howard			11/96
//
//	Copyright �1995,1996 Progressive Networks, Inc.
//	All Rights Reserved.
//

#include "windows.h"
#include "commctrl.h"
#include "stdio.h"
#include "resrc6.h"
#include "RaLivEnc.h"
#include "racodec.h"

#include <math.h>
#include <mmsystem.h>
#include <mmreg.h>
//////////////////////////

// default waveIn settings 
#define SAMPLE_RATE	44100
#define	CHANNELS	2
#define SAMPLE_SIZE	16

#define HDR_SIZE	sizeof(WAVEHDR)
#define PBAR		0x100000

//////////////////////

void CALLBACK WaveProc(HWAVE, UINT, DWORD, DWORD, DWORD);
void Wave(MMRESULT);
void RA30(PN_ERROR);
void WaveCollapse(MMRESULT);

void InitWAVEFORMATEX	(LPWAVEFORMATEX);
void InitWAVEHDR		(LPWAVEHDR, LPSTR, DWORD);


HWAVE	hwi			= NULL;
DWORD	SampleRate	= SAMPLE_RATE;
WORD	SampleSize	= SAMPLE_SIZE;
WORD	Channels	= CHANNELS;
WORD	FrameSize	= Channels * SampleSize / 8;

DWORD	xBytes		= 0;
DWORD	xTotal		= 0;

BOOL	Running = FALSE;

//////////////////////////

extern HINSTANCE	hInstance;
extern BOOL	ENCODING;

// the encoder object
RA_Encoder		enc = NULL;

// a flavor handle
PNFlavorHandle	flavor;

PN_ERROR encode_wav(HWND, RA_Encoder, PN_AUDIO_FORMAT, ULONG32);

void DoInit(HWND w)
{	
	// create a list of availible codecs which conform to the
	// content type we wish to encode
	RAenc_PackageInit(PN_CONTENT_VOICE | PN_CONTENT_MUSIC);

	// create an encoder
	enc = RAenc_Create();
	
	// choose the flavor we want to use, based on properties
	UINT16 numFlavors = RAenc_GetNumFlavors(enc);
	UINT16 index;
	char codecname[MAX_PATH];	
	void* flavname;
	UINT16 buflen;

	// grab the handle of the dialog's combo box, so we can add
	// codec flavors to it.
	HWND ctl = GetDlgItem(w, IDC_COMBO_CODEC);
	
	// iterate through all the flavors we found
	for (index = 0; index < numFlavors; index++)
	{
		if (RAenc_GetFlavorByIndex(enc, index, &flavor) != PN_NO_ERROR)
			MessageBox(NULL, "Bad flavor index!", NULL, MB_OK);
	  	else
		{
			// Grab the name of the flavor
			RAenc_GetFlavorProperty	(enc, flavor, FLV_PROP_NAME, &flavname, &buflen);

			// convert it into a string
			strncpy(codecname, (char*)flavname, buflen);

			// put it in the combo box
			SendMessage(ctl, CB_ADDSTRING, 0, (LPARAM)codecname);
		}	
	}	
	// set default value in the codec combo box
	SendMessage(GetDlgItem(w, IDC_COMBO_CODEC), CB_SETCURSEL, 0, 0);

	//  destroy the encoder
	RAenc_Destroy(enc);
	/////
}

void DoAbort(void)
{
	if (Running) {
	// abort the encoding process
		Running = FALSE;
		xBytes	= 0;
		RAenc_Abort(enc, FALSE);
		waveInStop(hwi);
		waveInReset(hwi);
		waveInClose(hwi);
		MessageBox(NULL, "DoAbort Completed", NULL, MB_OK);
	}
}

void DoEncode(HWND w, ENAPP_OPTIONS *pOptions)
{
	//  here's where the sound file gets encoded.  We initialize the
	//  encoder with the desired codec, make a few adjustments based
	//  on the attributes of the sound data, and begin encoding.		
	
	// create an encoder
	enc = RAenc_Create();
		
	// get the desired codec flavor -- this was taken from the dialog's
	// combo box index when the 'Encode' button was clicked.
	
	if (RAenc_GetFlavorByIndex(enc, (UINT16)pOptions->_codec, &flavor) != PN_NO_ERROR) 
	{
		MessageBox(NULL, "Bad flavor index!  Check your system for duplicate/obsolete codec DLLs", NULL, MB_OK);
		return;
	}
	
	PN_AUDIO_FORMAT info;
		info.FormatTag		= 1;
		info.SamplesPerSec	= 44100;
		info.BitsPerSample	= 16;
		info.Channels		= 2;

	// initialize encoder with the desired codec flavor
	if (RAenc_InitializeEncoder(enc, flavor, &info))
	{
		MessageBox(NULL, "Encoder failed to initialize!", NULL, MB_OK);
		return;
	}
				
	// we want to encode live to server, so set destination there
	RAenc_SetDestination(enc, PN_ENC_DEST_SERVER);

	// give the encoder an output filename
	if (RAenc_SetOutputFile(enc, pOptions->_output))
	{
		MessageBox(NULL, "Cannot open desired output file. Possible reasons:  The file may be corrupted, an unsupported format, or in use by another application.", NULL, MB_OK);
		return;
	}

	// what size data chunks are we working with?  These are both in bytes
	// that is a change from 2.1
	ULONG32 bytesIn, bytesOut;
	// this will tell us if the encoder 'plans' to do sample rate coversion
	BOOL    reSample;
				
	RAenc_GetBufferSizes(enc, &bytesIn, &bytesOut, &reSample);

	// set the clip's attributes
	RAenc_Title			(enc, pOptions->_title);
	RAenc_Author		(enc, pOptions->_author);
	RAenc_Copyright		(enc, pOptions->_copyright);
	RAenc_SelRecBit		(enc, pOptions->_selectiverecord);
			
	xBytes = xTotal = 0;
	// start the encoder
	if (RAenc_Start(enc))
	{
		MessageBox(NULL, "Encoder Start failed!", NULL, MB_OK);
		return;
	}
	
	// try to connect to server
	if (RAenc_ConnectToServer(enc, pOptions->_server, pOptions->_password, atoi(pOptions->_portnum), 512, 50000, TRUE))
	{
		MessageBox(NULL, "Couldn't connect to server!", NULL, MB_OK);
		return;
	}
			
	// encode and write the file
	encode_wav(w, enc, info, bytesIn);
				
	//  tell the encoder to flush any remaining data and write
	//  the appropriate .RA file header data
	RAenc_Done(enc);

	// destroy the encoder
	RAenc_Destroy(enc);
}

//
//   encode MM waveIn stream
//

PN_ERROR encode_wav(HWND w, RA_Encoder enc, PN_AUDIO_FORMAT info, ULONG32 bytesIn)
{
	PN_ERROR pnerr = PN_NO_ERROR;	
	// waveIn 
	MMRESULT mmerr = MMSYSERR_NOERROR;
	WAVEFORMATEX	fmt;
	WAVEHDR			ihdr1;
	WAVEHDR			ihdr2;
	
	short *inBuf	= new short [bytesIn];
	short *buf1		= new short	[bytesIn];
	short *buf2		= new short	[bytesIn];
		
	InitWAVEFORMATEX(&fmt);
	InitWAVEHDR(&ihdr1, (LPSTR)buf1, bytesIn);	
	InitWAVEHDR(&ihdr2, (LPSTR)buf2, bytesIn);	

	// set up the progress bar
	RECT rcClient;
	GetClientRect(w, &rcClient);
	int cyVScroll	= GetSystemMetrics(SM_CYVSCROLL);
	HWND hwndPB = CreateWindowEx(0, PROGRESS_CLASS, (LPSTR)NULL, WS_CHILD | WS_VISIBLE, rcClient.left, rcClient.bottom - cyVScroll, rcClient.right, cyVScroll, w, (HMENU)0, hInstance, NULL);

	/////////////////////////////////////////
	// open the wave input device
	/////////////////////////////////////////
	UINT		deviceID = 0;
	
	Wave(waveInOpen(&hwi, deviceID, &fmt, (DWORD)WaveProc, 0, CALLBACK_FUNCTION));

	////////////////////////////////////////////////////////
	// to avoid audio jitter, we need to prepare TWO headers 
	// for double-buffering wave input
	////////////////////////////////////////////////////////
	Wave(waveInPrepareHeader(hwi, &ihdr1, HDR_SIZE));
	Wave(waveInAddBuffer	(hwi, &ihdr1, HDR_SIZE));
	
	Wave(waveInPrepareHeader(hwi, &ihdr2, HDR_SIZE));
	Wave(waveInAddBuffer	(hwi, &ihdr2, HDR_SIZE));

	Running	= TRUE;
	Wave(waveInStart(hwi));

	// let's do a progress indicator, so we know something's happening.
	
	MSG m;
	ULONG delta;
	while (Running) {
		delta = 100 * xBytes / PBAR;
		SendMessage(hwndPB, PBM_SETPOS, (WPARAM)(delta), 0);
		// process any waiting messages					
		if (PeekMessage(&m, NULL, 0, 0, PM_REMOVE) == TRUE)
		{
			if (m.message == WM_QUIT)
			{
				DestroyWindow(hwndPB);
				return pnerr;
			}
			TranslateMessage(&m);
			DispatchMessage(&m);
		}
	}

	delete [] inBuf;
	delete [] buf1;
	delete [] buf2;

	return pnerr;
}

void RaError(char *errstr) {	
	MessageBox(NULL, errstr, NULL, MB_OK);
}

/////////////////////////////////////////////////////////
//
//	Line-In (CD/Mic/etc.) -> waveIn -> RAenc -> Server
//
//////////////////////////////////////////////////////////

// Wave callback
void CALLBACK WaveProc(HWAVE h, UINT msg, DWORD inst, DWORD par1, DWORD par2) {
	LPWAVEHDR	hdr = (LPWAVEHDR)par1;
	DWORD		outlen;
	DWORD		nextEncodeSize;	
	
	switch (msg) {
	case WIM_CLOSE:
		break;
	case WIM_OPEN:
		break;
	case WIM_DATA:
		waveInUnprepareHeader (hwi, hdr, HDR_SIZE);		

		xBytes += hdr->dwBytesRecorded;
		xTotal += hdr->dwBytesRecorded;
		if (xBytes > PBAR)
			xBytes = 0;

		RAenc_Encode(enc, (INT16 *)hdr->lpData, hdr->dwBytesRecorded, NULL, &outlen, NULL, &nextEncodeSize);
		if (Running) {
			if (hdr->dwBufferLength != nextEncodeSize)
			{
				hdr->dwBufferLength = nextEncodeSize;
				MessageBox(NULL, "len!=next", NULL, MB_OK);
			}
			waveInPrepareHeader		(hwi, hdr, HDR_SIZE);
			waveInAddBuffer			(hwi, hdr, HDR_SIZE);
		}
		break;
	default:
		MessageBox(NULL, "<W?M_WHAT>", NULL, MB_OK);
		break;
	}
}

void InitWAVEFORMATEX(LPWAVEFORMATEX fmt) {
	if (fmt != NULL) {
		fmt->wFormatTag			= WAVE_FORMAT_PCM;
		fmt->nChannels			= Channels;		
		fmt->nSamplesPerSec		= SampleRate;
		fmt->nAvgBytesPerSec	= SampleRate * FrameSize;
		fmt->nBlockAlign		= FrameSize;
		fmt->wBitsPerSample		= SampleSize;
		fmt->cbSize				= 0;
	}
}

void InitWAVEHDR(LPWAVEHDR hdr, LPSTR buf, DWORD buflen) {
	if (hdr != NULL) {
		hdr->lpData				= buf;
		hdr->dwBufferLength		= buflen;
		hdr->dwBytesRecorded	= 0; 
		hdr->dwUser				= 0;
		hdr->dwFlags			= 0; 
		hdr->dwLoops			= 0; 
		hdr->lpNext				= 0;
		hdr->reserved			= 0; 
	}
}

// Error trapping and debug info wrapper procedures

void Wave(MMRESULT mmerr) {
	if (mmerr) {
		Running = FALSE;
		WaveCollapse(mmerr);
	}
}

void RA30(PN_ERROR pnerr) {
	if (pnerr) {
		Running = FALSE;	
	}
}

void WaveCollapse(MMRESULT err) {
	char errstr[MAX_PATH];

	waveInGetErrorText(err, errstr, MAX_PATH);	
	MessageBox(NULL, errstr, NULL, MB_OK);
	waveInStop	(hwi);
	waveInReset	(hwi);
	waveInClose	(hwi);
}
