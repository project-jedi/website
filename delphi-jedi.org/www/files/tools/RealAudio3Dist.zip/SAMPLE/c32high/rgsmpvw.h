/////////////////////////////////////////////////////////////////////////////
//
//      RGSMPVW.H
//
//  	Interface of the CRGSmpView class.  This file was created with
//  	MSVC 2.2 AppWizard.  No RealAudio code has been added, other than
//  	function declarations.
//
//      Adam D. Schaeffer          6/1/96
//
//      Copyright �1995,1996 Progressive Networks, Inc.  All rights reserved.
//
//      

// include the necessary files
#include "ragui.h"

class CRGSmpView : public CView
{
protected: // create from serialization only
	CRGSmpView();
	DECLARE_DYNCREATE(CRGSmpView)

// Attributes
public:
	CRGSmpDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRGSmpView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CRGSmpView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CRGSmpView)
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnAudioOpenConsole();
	afx_msg void OnAudioCloseConsole();
	afx_msg void OnUpdateAudioPreferences(CCmdUI* pCmdUI);
	afx_msg void OnUpdateAudioCloseconsole(CCmdUI* pCmdUI);
	afx_msg void OnUpdateAudioConsoleoptionsButtons(CCmdUI* pCmdUI);
	afx_msg void OnUpdateAudioConsoleoptionsStatusbar(CCmdUI* pCmdUI);
	afx_msg void OnUpdateAudioConsoleoptionsVolume(CCmdUI* pCmdUI);
	afx_msg void OnUpdateAudioShowstatistics(CCmdUI* pCmdUI);
	afx_msg void OnUpdateAudioPlaynextitem(CCmdUI* pCmdUI);
	afx_msg void OnAudioPlay();
	afx_msg void OnUpdateAudioPlay(CCmdUI* pCmdUI);
	afx_msg void OnAudioPlaynextitem();
	afx_msg void OnUpdateAudioPlaypreviousitem(CCmdUI* pCmdUI);
	afx_msg void OnAudioPlaypreviousitem();
	afx_msg void OnAudioAutostart();
	afx_msg void OnUpdateAudioAutostart(CCmdUI* pCmdUI);
	afx_msg void OnAudioStop();
	afx_msg void OnUpdateAudioStop(CCmdUI* pCmdUI);
	afx_msg void OnUpdateConsoleShowtitles(CCmdUI* pCmdUI);
	afx_msg void OnConsoleShowtitles();
	afx_msg void OnConsoleTeststatusbar();
	afx_msg void OnUpdateConsoleTeststatusbar(CCmdUI* pCmdUI);
	afx_msg void OnUpdateConsoleEnablestatusbaruse(CCmdUI* pCmdUI);
	afx_msg void OnConsoleEnablestatusbaruse();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in RGSmpvw.cpp
inline CRGSmpDoc* CRGSmpView::GetDocument()
   { return (CRGSmpDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////
