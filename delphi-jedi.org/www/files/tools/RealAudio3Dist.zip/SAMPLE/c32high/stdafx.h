/////////////////////////////////////////////////////////////////////////////
//
//      STDAFX.H
//
//  	include file for standard system include files, or project specific 
//  	include files that are used frequently, but are changed infrequently
//
// 	 	This file was created with MSVC 2.2 AppWizard.  No RealAudio code has
//  	been added.
//
//      Adam D. Schaeffer          6/1/96
//
//      Copyright �1995,1996 Progressive Networks, Inc.  All rights reserved.
//
//      


#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
