//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by rgsmp.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_RGSMPTYPE                   129
#define IDD_GETURLDIALOG                130
#define IDC_EDITURL                     1000
#define ID_AUDIO_OPENCONSOLE            32771
#define ID_AUDIO_CLOSECONSOLE           32772
#define ID_AUDIO_CONSOLEOPTIONS_ALL     32773
#define ID_AUDIO_CONSOLEOPTIONS_VOLUME  32774
#define ID_AUDIO_CONSOLEOPTIONS_BUTTONS 32775
#define ID_AUDIO_CONSOLEOPTIONS_STATUSBAR 32776
#define ID_AUDIO_PREFERENCES            32778
#define ID_AUDIO_SHOWSTATISTICS         32779
#define ID_FILE_OPENFILE                32780
#define ID_FILE_OPENURL                 32781
#define ID_AUDIO_PLAY                   32782
#define ID_AUDIO_STOP                   32784
#define ID_AUDIO_PLAYNEXTITEM           32787
#define ID_AUDIO_PLAYPREVIOUSITEM       32788
#define ID_AUDIO_AUTOSTART              32789
#define ID_CONSOLE_SHOWTITLES           32790
#define ID_CONSOLE_TESTSTATUSBAR        32791
#define ID_CONSOLE_ENABLESTATUSBARUSE   32792
#define IDS_URLDLG_TITLE                61204
#define IDS_STATUSBAR_1                 61205
#define IDS_STATUSBAR_2                 61206
#define IDS_STATUSBAR_3                 61207
#define IDS_STATUSBAR_4                 61208

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32793
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
