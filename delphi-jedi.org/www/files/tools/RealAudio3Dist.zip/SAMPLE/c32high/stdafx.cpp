/////////////////////////////////////////////////////////////////////////////
//
//      STDAFX.CPP
//
//  	Source file that includes just the standard header files.
//  	RGSmp.pch will be the pre-compiled header
//		stdafx.obj will contain the pre-compiled type information
//
//      Adam D. Schaeffer          6/1/96
//
//      Copyright �1995,1996 Progressive Networks, Inc.  All rights reserved.
//
//      


#include "stdafx.h"

