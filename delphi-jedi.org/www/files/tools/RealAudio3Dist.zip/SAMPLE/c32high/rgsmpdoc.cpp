/////////////////////////////////////////////////////////////////////////////
//
//      RGSMPDOC.CPP
//
//  	Implementation of the CRGSmpDoc class.  This file was created with
//  	MSVC 2.2 AppWizard.  No RealAudio code has been added.
//
//      Adam D. Schaeffer          6/1/96
//
//      Copyright �1995,1996 Progressive Networks, Inc.  All rights reserved.
//
//      


#include "stdafx.h"
#include "RGSmp.h"

#include "RGSmpdoc.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRGSmpDoc

IMPLEMENT_DYNCREATE(CRGSmpDoc, CDocument)

BEGIN_MESSAGE_MAP(CRGSmpDoc, CDocument)
	//{{AFX_MSG_MAP(CRGSmpDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRGSmpDoc construction/destruction

CRGSmpDoc::CRGSmpDoc()
{
	// TODO: add one-time construction code here

}

CRGSmpDoc::~CRGSmpDoc()
{
}

BOOL CRGSmpDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CRGSmpDoc serialization

void CRGSmpDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CRGSmpDoc diagnostics

#ifdef _DEBUG
void CRGSmpDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CRGSmpDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CRGSmpDoc commands
