/////////////////////////////////////////////////////////////////////////////
//
//      RGSMP.H
//
//  	Main header file for the RGSMP application.  This file was created with
//  	MSVC 2.2 AppWizard.  No RealAudio code has been added.
//
//      Adam D. Schaeffer          6/1/96
//
//      Copyright �1995,1996 Progressive Networks, Inc.  All rights reserved.
//
//      


#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resrc1.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CRGSmpApp:
// See RGSmp.cpp for the implementation of this class
//

class CRGSmpApp : public CWinApp
{
public:
	CRGSmpApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRGSmpApp)
	public:
	virtual BOOL InitInstance();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CRGSmpApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

