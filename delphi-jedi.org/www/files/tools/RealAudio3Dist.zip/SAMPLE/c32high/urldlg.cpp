/////////////////////////////////////////////////////////////////////////////
//
//      URLDLG.CPP
//
//  	Implementation of the CURLDlg class.  This file was created with
//  	MSVC 2.2 AppWizard, and code has been added to interact with Ragui32.DLL
//
//      Adam D. Schaeffer          6/1/96
//
//      Copyright �1995,1996 Progressive Networks, Inc.  All rights reserved.
//
//      

#include "stdafx.h"
#include "RGSmp.h"
#include "urldlg.h"

#include "ragui.h"
#include "pnerrors.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

//  so we can interact with the console
extern RaguiInstanceId 		g_raInstanceId;
extern BOOL					g_AutoStart;


/////////////////////////////////////////////////////////////////////////////
// CURLDlg dialog


CURLDlg::CURLDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CURLDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CURLDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CURLDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CURLDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CURLDlg, CDialog)
	//{{AFX_MSG_MAP(CURLDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CURLDlg message handlers

void CURLDlg::OnOK() 
{
	// The User has chosen a URL
	char	szURL[256];

	GetDlgItemText(IDC_EDITURL,	szURL, 256);
	if (g_raInstanceId) {
		// send the clip to ragui
		RaguiSetSource(g_raInstanceId, szURL);

		// give ragui the value of our autostart flag
		if (RaguiSetAutoStart(g_raInstanceId, g_AutoStart) != PN_NO_ERROR)
				MessageBox("File cannot AutoStart");
	}

	CDialog::OnOK();
}

BOOL CURLDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	SetDlgItemText(IDC_EDITURL, "pnm://audio.realaudio.com/welcome.ra");	

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
