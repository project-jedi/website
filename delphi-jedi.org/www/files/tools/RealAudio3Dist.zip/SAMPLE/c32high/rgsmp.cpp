/////////////////////////////////////////////////////////////////////////////
//
//      RGSMP.CPP
//
//  	Defines the class behaviors for the application.  This file was created with
//  	MSVC 2.2 AppWizard.  If you develop with an MFC version later than 2.2, be
//		sure to look at the implementation of CRGSmpApp::PreTranslateMessage() at
//		the end of this file.
//                                                                     
//      Adam D. Schaeffer          6/1/96
//
//      Copyright �1995,1996 Progressive Networks, Inc.  All rights reserved.
//
//      


#include "stdafx.h"
#include "RGSmp.h"

#include "mainfrm.h"
#include "RGSmpdoc.h"
#include "RGSmpvw.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRGSmpApp

BEGIN_MESSAGE_MAP(CRGSmpApp, CWinApp)
	//{{AFX_MSG_MAP(CRGSmpApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRGSmpApp construction

CRGSmpApp::CRGSmpApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CRGSmpApp object

CRGSmpApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CRGSmpApp initialization

BOOL CRGSmpApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

	Enable3dControls();

	LoadStdProfileSettings(0);  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CRGSmpDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CRGSmpView));
	AddDocTemplate(pDocTemplate);

	// create a new (empty) document
	OnFileNew();

	if (m_lpCmdLine[0] != '\0')
	{
		// TODO: add command line processing here
	}

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CRGSmpApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

//////////////////////////////////////////////////////////////////////////
//
//  I M P O R T A N T !
//
//	Due to a change in the way MFC implements this function (new since
//	2.2), we need to overload this function.  This is because an
//	instance of ragui can have a null window handle.
// 
BOOL CRGSmpApp::PreTranslateMessage(MSG* pMsg) 
{
	if ( (pMsg->message==WM_TIMER) && (pMsg->hwnd==NULL) )
		return FALSE;

	return CWinApp::PreTranslateMessage(pMsg);
}
