/////////////////////////////////////////////////////////////////////////////
//
//      URLDLG.H
//
//  	Interface of the CURLDlg class.  This file was created with
//  	MSVC 2.2 AppWizard, and code has been added to interact with Ragui32.DLL
//
//      Adam D. Schaeffer          6/1/96
//
//      Copyright �1995,1996 Progressive Networks, Inc.  All rights reserved.
//
//      


/////////////////////////////////////////////////////////////////////////////
// CURLDlg dialog

class CURLDlg : public CDialog
{
// Construction
public:
	CURLDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CURLDlg)
	enum { IDD = IDD_GETURLDIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CURLDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CURLDlg)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
