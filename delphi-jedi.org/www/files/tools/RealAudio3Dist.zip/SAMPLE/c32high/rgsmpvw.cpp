/////////////////////////////////////////////////////////////////////////////
//
//      RGSMPVW.CPP
//
//  	Implementation of the CRGSmpView class.  This file was created with
//  	MSVC 2.2 AppWizard, and code has been added to interact with Ragui32.DLL
//
//      Adam D. Schaeffer          6/1/96
//
//      Copyright �1995,1996 Progressive Networks, Inc.  All rights reserved.
//
//      


#include "stdafx.h"
#include "windows.h"
#include "RGSmp.h"

#include "RGSmpdoc.h"
#include "RGSmpvw.h"
#include "mainfrm.h"

// include the necessary files
#include "pnerrors.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Ragui Global Variables

extern RaguiClientId		g_ClientID      = NULL;
extern RaguiInstanceId 		g_raInstanceId  = NULL;
extern PNxWindow*		    g_pWindow	    = NULL;

extern BOOL 				g_ShowStatus;
extern BOOL 				g_ShowButtons;
extern BOOL 				g_ShowVolume;

extern BOOL					g_ShowNoTitles  = FALSE;
extern BOOL					g_AutoStart 	= FALSE;

BOOL						g_UseStatusBar  = FALSE;
BOOL						g_Playing		= FALSE;


/////////////////////////////////////////////////////////////////////////////
// CRGSmpView

IMPLEMENT_DYNCREATE(CRGSmpView, CView)

BEGIN_MESSAGE_MAP(CRGSmpView, CView)
	//{{AFX_MSG_MAP(CRGSmpView)
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_COMMAND(ID_AUDIO_OPENCONSOLE, OnAudioOpenConsole)
	ON_COMMAND(ID_AUDIO_CLOSECONSOLE, OnAudioCloseConsole)
	ON_UPDATE_COMMAND_UI(ID_AUDIO_PREFERENCES, OnUpdateAudioPreferences)
	ON_UPDATE_COMMAND_UI(ID_AUDIO_CLOSECONSOLE, OnUpdateAudioCloseconsole)
	ON_UPDATE_COMMAND_UI(ID_AUDIO_CONSOLEOPTIONS_BUTTONS, OnUpdateAudioConsoleoptionsButtons)
	ON_UPDATE_COMMAND_UI(ID_AUDIO_CONSOLEOPTIONS_STATUSBAR, OnUpdateAudioConsoleoptionsStatusbar)
	ON_UPDATE_COMMAND_UI(ID_AUDIO_CONSOLEOPTIONS_VOLUME, OnUpdateAudioConsoleoptionsVolume)
	ON_UPDATE_COMMAND_UI(ID_AUDIO_SHOWSTATISTICS, OnUpdateAudioShowstatistics)
	ON_UPDATE_COMMAND_UI(ID_AUDIO_PLAYNEXTITEM, OnUpdateAudioPlaynextitem)
	ON_COMMAND(ID_AUDIO_PLAY, OnAudioPlay)
	ON_UPDATE_COMMAND_UI(ID_AUDIO_PLAY, OnUpdateAudioPlay)
	ON_COMMAND(ID_AUDIO_PLAYNEXTITEM, OnAudioPlaynextitem)
	ON_UPDATE_COMMAND_UI(ID_AUDIO_PLAYPREVIOUSITEM, OnUpdateAudioPlaypreviousitem)
	ON_COMMAND(ID_AUDIO_PLAYPREVIOUSITEM, OnAudioPlaypreviousitem)
	ON_COMMAND(ID_AUDIO_AUTOSTART, OnAudioAutostart)
	ON_UPDATE_COMMAND_UI(ID_AUDIO_AUTOSTART, OnUpdateAudioAutostart)
	ON_COMMAND(ID_AUDIO_STOP, OnAudioStop)
	ON_UPDATE_COMMAND_UI(ID_AUDIO_STOP, OnUpdateAudioStop)
	ON_UPDATE_COMMAND_UI(ID_CONSOLE_SHOWTITLES, OnUpdateConsoleShowtitles)
	ON_COMMAND(ID_CONSOLE_SHOWTITLES, OnConsoleShowtitles)
	ON_COMMAND(ID_CONSOLE_TESTSTATUSBAR, OnConsoleTeststatusbar)
	ON_UPDATE_COMMAND_UI(ID_CONSOLE_TESTSTATUSBAR, OnUpdateConsoleTeststatusbar)
	ON_UPDATE_COMMAND_UI(ID_CONSOLE_ENABLESTATUSBARUSE, OnUpdateConsoleEnablestatusbaruse)
	ON_COMMAND(ID_CONSOLE_ENABLESTATUSBARUSE, OnConsoleEnablestatusbaruse)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CRGSmpView construction/destruction

CRGSmpView::CRGSmpView()
{
	// create a new platform-independent window structure for
	// our global handle
	g_pWindow = new PNxWindow();
}

CRGSmpView::~CRGSmpView()
{
 	// destroy the console, if it exists
	if (g_raInstanceId)
	{
		RaguiDestroy(g_raInstanceId);
	    RaguiShutdownClient(g_ClientID);
	}
}


/////////////////////////////////////////////////////////////////////////////
// CRGSmpView drawing

void CRGSmpView::OnDraw(CDC* pDC)
{
	CRGSmpDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
}


void CRGSmpView::OnPaint()
{
	// This paints a light-grey background... the Ragui console looks
	// much better that way...

	// Set up device context (DC) for drawing
    CPaintDC dc(this);
	dc.SetBkColor( RGB(192,192,192) );   
    dc.SetBkMode(TRANSPARENT);

	// Get window size
    CRect r;
    GetClientRect(r);

    int w = r.right - r.left;
    int h = r.bottom - r.top;

	// get a brush, use it, and delete it
	CBrush *hbr = new CBrush(RGB(192,192,192));
	dc.FillRect(r, hbr);
	delete hbr;

	// send the paint message on to the parent class... 
	CWnd::OnPaint();
}

void CRGSmpView::OnSize(UINT nType, int cx, int cy)
{
	// if the window resizes, we need to inform the console!
	if (g_raInstanceId)
		RaguiResizeWindow(g_raInstanceId);
}


/////////////////////////////////////////////////////////////////////////////
// CRGSmpView diagnostics

#ifdef _DEBUG
void CRGSmpView::AssertValid() const
{
	CView::AssertValid();
}

void CRGSmpView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CRGSmpDoc* CRGSmpView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CRGSmpDoc)));
	return (CRGSmpDoc*)m_pDocument;
}
#endif //_DEBUG


/////////////////////////////////////////////////////////////////////////////
// Callback functions for Ragui
//
//   watch the Ragui Status bar... you'll see these callbacks fire.  You'll
//   need to take control of the ragui status bar from the "Audio->
//	 Enable Status Bar Use"	menu to see them.
//

void GoToURLCallback(RaguiInstanceId Id, char* pClipShortName, char* pClipURL)
{
	RaguiStatusScan(g_raInstanceId, "GoToURL Callback");
	
	// We can use this callback to test the RaguiShowAbout() API call, 
	// or handle synchronized media stream information.
	// To cause this callback to fire, click the "word balloon" on the console
	
	// uncomment the following code to display callback info
	
	// char text[256];	
	// is this synch callback generated by media info or by clicking the word balloon? 
	// if (strcmp(pClipURL, "_blank")) {
 	// 	sprintf(text, "GoToURLCallback() a stream event occurred:\n\n %s\n Media: %s\n\nClick OK to continue.", pClipShortName, pClipURL);
	// 	AfxMessageBox(text, MB_ICONINFORMATION);
	// }
	// else
	//	RaguiShowAbout(g_raInstanceId);
}

void ShowStatusCallback(RaguiInstanceId Id, char* pClipShortName, char* pClipURL)
{
	
}

void ClipOpenedCallback(RaguiInstanceId Id, char* pClipShortName, char* pClipURL)
{
	RaguiStatusScan(g_raInstanceId, "ClipOpened Callback");
	// the strings will be NULL if the clip is closed, and valid if it
	// is opened
	if (pClipShortName)
		g_Playing = TRUE;
	else
		g_Playing = FALSE;
}

void PrefsChangedCallback(RaguiInstanceId Id)
{
	RaguiStatusScan(g_raInstanceId, "PrefsChanged Callback");
}

/////////////////////////////////////////////////////////////////////////////
// CRGSmpView message handlers

void CRGSmpView::OnAudioOpenConsole() 
{
	RaguiClientInfo 			ClientInfo;

	// for this app, one console is plenty
	if (g_raInstanceId) {
		CWnd::MessageBox("You already have a console open.", "Wait a sec' pardner!");
		return;
	}
	
	// let's find out what version of the DLLs we're using
	ULONG32 RaguiVersion = RaguiProductVersion();
	char AppPreRelease[64];
	
	wsprintf(AppPreRelease, "Ragui Version %d.%d.%d.%d",
				RAGUI_GET_MAJOR_VERSION(RaguiVersion),
				RAGUI_GET_MINOR_VERSION(RaguiVersion),
				RAGUI_GET_RELEASE_NUMBER(RaguiVersion),
				RAGUI_GET_BUILD_NUMBER(RaguiVersion) );
	
	const char* AppName      	= "RGSmp";
	const char* AppLongName  	= "RealAudio� SDK Sample Application";
	const char* AppVersion   	= "1.0";
	const char* AppLang      	= "EN";
	const char* AppDistCode  	= "Prognet";
	const char* AppCopyright 	= "Copyright(c) 1996 Progressive Networks, Inc.";
	const char*	AppMoreInfoURL	= "http://www.realaudio.com/";

	// Need Proper ClientID strings...  Make sure you read the docs
	// on the structure of ClientID strings.
	char IDBuffer[512];
	
	if (RaguiFormClientIdString(IDBuffer, 512, AppName, 
								AppVersion, AppLang,
								AppDistCode) > PN_NO_ERROR)
	{
		strcpy(IDBuffer, "Unknown ClientID String");
	}

	// assign the handle of our window to the platform-independent window structure
	g_pWindow->window = m_hWnd;

	// this step is important if you might be mixing dll versions.
	// it attempts to keep uninitialized callbacks from firing.
	memset(&ClientInfo, 0, sizeof(RaguiClientInfo));

	// set up the RaguiClientInfo struct...
	ClientInfo.nSize 			= sizeof(RaguiClientInfo);
	ClientInfo.GoToURL			= (GOTOURLPROC)GoToURLCallback;
	ClientInfo.ShowStatus		= (SHOWSTATUSPROC)ShowStatusCallback;
	ClientInfo.ClipOpened		= (CLIPOPENEDPROC)ClipOpenedCallback;
	ClientInfo.PrefsChanged		= (PREFSCHANGEDPROC)PrefsChangedCallback;
	ClientInfo.pOwnerWindow 	= g_pWindow;
	ClientInfo.pClientID		= IDBuffer;
	ClientInfo.pShortProdName	= AppName;
	ClientInfo.pLongProdName	= AppLongName;
	ClientInfo.pProdVersion		= AppVersion;
	ClientInfo.pPreRelease		= AppPreRelease;
	ClientInfo.pCopyright		= AppCopyright;
	ClientInfo.pMoreInfoURL		= AppMoreInfoURL;

	// let's get the console on the screen!
	PN_ERROR sError = RaguiSetupClient(&ClientInfo, &g_ClientID);
	if (sError > 0) {
		char foo[128];
		wsprintf(foo, "RaguiSetupClient() error: %d", sError);
		CWnd::MessageBox(foo, "OOPS!");
	} else {

		if (RaguiNew(g_ClientID, &g_raInstanceId) > 0) {
			CWnd::MessageBox("Error during RaguiNew().", "OOPS!");
		} else {

			// set a unique console name
			RaguiSetConsoleName(g_raInstanceId, UNIQUE_CONSOLE_NAME, TRUE);

			// set the conrols we want on the console -- to see how these global
			// variables get their values, look at MAINFRM.CPP.  This call is not
			// necessary to make the console work; by default the console contains
			// all the controls. 
			RaguiSetControlsFlags(g_raInstanceId, g_ShowVolume | g_ShowButtons | g_ShowStatus);
			RaguiSetNoLabels(g_raInstanceId, g_ShowNoTitles);

			if (RaguiSetWindow(g_raInstanceId, g_pWindow) > 0) {
				CWnd::MessageBox("Error during RaguiSetWindow()", "OOPS!" );
			} else {

				//  if we've gotten this far, we have a visible, functioning console,
				//  with all the controls (the default setting)

				//  update the window to take care of any necessary refreshing
				CWnd::InvalidateRect(NULL);
				CWnd::UpdateWindow();

				// give ragui the value of our autostart flag
				RaguiSetAutoStart(g_raInstanceId, g_AutoStart);
				
				// just for fun, let's open a URL:
				char szResource[] = "pnm://audio.realaudio.com/welcome.ra";
				
				// alternately, we could open a *.RA file
				//char szResource[] = "c:\\raplayer\\thankyou.ra";

				// or we could open a *.RAM file
				// (the START.RAM file which the PLAYER installs needs to be
				// modified to contain the full path name of the *.RA files or
				// this app won't find them)
				
				//char szResource[] = "c:\\raplayer\\start.ram";

				// tell ragui what we want to play (remember, it's set to play
				// automatically.
				RaguiSetSource(g_raInstanceId, szResource);
			}
		}
	}
}

void CRGSmpView::OnAudioCloseConsole() 
{
	// destroy the console, if it exists
	if (g_raInstanceId)
	{
		RaguiDestroy(g_raInstanceId);
		RaguiShutdownClient(g_ClientID);
	 	g_raInstanceId = NULL;
	}

	// and refresh the window
	Invalidate(FALSE);
	UpdateWindow();
}

void CRGSmpView::OnUpdateAudioPreferences(CCmdUI* pCmdUI) 
{
	// only allow user to change preferences if we have a console
	// to act on.
	
	if ( g_raInstanceId && !g_Playing ) {
		pCmdUI->Enable(TRUE);
	} else {
		pCmdUI->Enable(FALSE);
	}	
}

void CRGSmpView::OnUpdateAudioCloseconsole(CCmdUI* pCmdUI) 
{
	// just for consistency, let's gray out options when they don't make sense.
	
	if (g_raInstanceId) {
		pCmdUI->Enable(TRUE);
	} else {
		pCmdUI->Enable(FALSE);
	}
}

void CRGSmpView::OnUpdateAudioConsoleoptionsButtons(CCmdUI* pCmdUI) 
{
	// just for consistency, let's gray out options when they don't make sense.
	
	if (g_raInstanceId) {
		pCmdUI->Enable(TRUE);
	} else {
		pCmdUI->Enable(FALSE);
	}
}

void CRGSmpView::OnUpdateAudioConsoleoptionsStatusbar(CCmdUI* pCmdUI) 
{
	// just for consistency, let's gray out options when they don't make sense.
	
	if (g_raInstanceId) {
		pCmdUI->Enable(TRUE);
	} else {
		pCmdUI->Enable(FALSE);
	}
}

void CRGSmpView::OnUpdateAudioConsoleoptionsVolume(CCmdUI* pCmdUI) 
{
	// just for consistency, let's gray out options when they don't make sense.
	
	if (g_raInstanceId) {
		pCmdUI->Enable(TRUE);
	} else {
		pCmdUI->Enable(FALSE);
	}	
}

void CRGSmpView::OnUpdateAudioShowstatistics(CCmdUI* pCmdUI) 
{
	// just for consistency, let's gray out options when they don't make sense.
	
	if (g_raInstanceId) {
		pCmdUI->Enable(TRUE);
	} else {
		pCmdUI->Enable(FALSE);
	}
	
}


///////////////////////////////////////////////////////////////
//
//  If we can play the next clip, then enable play next.

void CRGSmpView::OnUpdateAudioPlaynextitem(CCmdUI* pCmdUI) 
{
	if (g_raInstanceId) {
		if (RaguiHasNextItem(g_raInstanceId)) {
			pCmdUI->Enable(TRUE);
		} else {
			pCmdUI->Enable(FALSE);
		}
	} else {
		pCmdUI->Enable(FALSE);
	}
}

void CRGSmpView::OnAudioPlaynextitem() 
{
	RaguiDoNextItem(g_raInstanceId);
}


///////////////////////////////////////////////////////////////
//
//  If we can play the previous clip, then enable play previous.

void CRGSmpView::OnUpdateAudioPlaypreviousitem(CCmdUI* pCmdUI) 
{
	if (g_raInstanceId) {
		if (RaguiHasPrevItem(g_raInstanceId)) {
			pCmdUI->Enable(TRUE);
		} else {
			pCmdUI->Enable(FALSE);
		}
	} else {
		pCmdUI->Enable(FALSE);
	}
}

void CRGSmpView::OnAudioPlaypreviousitem() 
{
	RaguiDoPrevItem(g_raInstanceId);
}


///////////////////////////////////////////////////////////////
//
//  If we can play, then enable play.

void CRGSmpView::OnUpdateAudioPlay(CCmdUI* pCmdUI) 
{
	if (g_raInstanceId) {
		if (RaguiCanPlayPause(g_raInstanceId)) {
			pCmdUI->Enable(TRUE);
		} else {
			pCmdUI->Enable(FALSE);
		}
	} else {
		pCmdUI->Enable(FALSE);
	}
}

void CRGSmpView::OnAudioPlay() 
{
	RaguiDoPlayPause(g_raInstanceId);
}


///////////////////////////////////////////////////////////////
//
//  If we can stop, then enable stop.

void CRGSmpView::OnUpdateAudioStop(CCmdUI* pCmdUI) 
{
	if (g_raInstanceId) {
		if (RaguiCanStop(g_raInstanceId)) {
			pCmdUI->Enable(TRUE);
		} else {
			pCmdUI->Enable(FALSE);
		}
	} else {
		pCmdUI->Enable(FALSE);
	}
	
}

void CRGSmpView::OnAudioStop() 
{
	RaguiDoStop(g_raInstanceId);
}


///////////////////////////////////////////////////////////////
//
//  Toggle AutoStart capability

void CRGSmpView::OnUpdateAudioAutostart(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(g_AutoStart);
}

void CRGSmpView::OnAudioAutostart() 
{	
	// toggle g_AutoStart
	if (g_AutoStart)
		g_AutoStart = FALSE;
	else
		g_AutoStart = TRUE;			
}


///////////////////////////////////////////////////////////////
//
//  Toggle NoLabels capability

void CRGSmpView::OnUpdateConsoleShowtitles(CCmdUI* pCmdUI) 
{
		pCmdUI->SetCheck(!g_ShowNoTitles);
}

void CRGSmpView::OnConsoleShowtitles() 
{
	
	// toggle g_ShowNoTitles
	if (g_ShowNoTitles)
		g_ShowNoTitles = FALSE;
	else
		g_ShowNoTitles = TRUE;

	if (g_raInstanceId) {
		RaguiSetNoLabels(g_raInstanceId, g_ShowNoTitles);
	}
	
}


///////////////////////////////////////////////////////////////
//
//  If we can write to the status bar, then enable the test.

void CRGSmpView::OnUpdateConsoleTeststatusbar(CCmdUI* pCmdUI) 
{
	if (g_UseStatusBar) {
		pCmdUI->Enable(TRUE);
	} else {
		pCmdUI->Enable(FALSE);
	}
}

void CRGSmpView::OnConsoleTeststatusbar() 
{
	static int count = 0;
	CString message;

		switch (count)
		{
			case 0:
				message.LoadString(IDS_STATUSBAR_1);
				break;

			case 1:
				message.LoadString(IDS_STATUSBAR_2);
				break;

			case 2:
				message.LoadString(IDS_STATUSBAR_3);
				break;

			case 3:
				message.LoadString(IDS_STATUSBAR_4);
				break;
		}

		// if RaguiStatusScanStart() has been called, then the console
		// status bar is ours to command.  Once we call RaguiStatusScanEnd(),
		// control over the status bar returns to ragui, and whatever we wrote
		// gets erased.  So it's not quite as simple as calling:
		//		RaguiStatusScanStart();
		//		RaguiStatusScan();
		//		RaguiStatusScanEnd();

		RaguiStatusScan(g_raInstanceId, message);

		count++;
		if (count > 3) count = 0;	
}


void CRGSmpView::OnUpdateConsoleEnablestatusbaruse(CCmdUI* pCmdUI) 
{
	if (g_raInstanceId) {
		pCmdUI->Enable(TRUE);
	} else {
		pCmdUI->Enable(FALSE);
	}

	pCmdUI->SetCheck(g_UseStatusBar);
}

void CRGSmpView::OnConsoleEnablestatusbaruse() 
{
	if (g_UseStatusBar)	{
		g_UseStatusBar = FALSE;
		// return control of the status bar to ragui
		RaguiStatusScanEnd(g_raInstanceId);
	} else {
		g_UseStatusBar = TRUE;
		// take control of the ragui status bar
		RaguiStatusScanStart(g_raInstanceId);
	}	
}
