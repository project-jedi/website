/////////////////////////////////////////////////////////////////////////////
//
//      MAINFRM.CPP
//
//  	Implementation of the CMainFrame class.  This file was created with
//  	MSVC 2.2 AppWizard, and code has been added to interact with Ragui32.DLL
//
//      Adam D. Schaeffer          6/1/96
//
//      Copyright �1995,1996 Progressive Networks, Inc.  All rights reserved.
//
//      


#include "stdafx.h"
#include "RGSmp.h"

#include "mainfrm.h"
#include "urldlg.h"

//  include the necessary files
#include "ragui.h"
#include "pnwintyp.h"
#include "pntypes.h"
#include "pnerrors.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// A few global variables to facilitate menu bar manipulation

BOOL  g_ShowStatus  = RACS_STATUSBAR;
BOOL  g_ShowButtons = RACS_BUTTONBAR;
BOOL  g_ShowVolume  = RACS_INFOVOLUMEBAR;

//  so we can interact with the console
extern RaguiInstanceId 		g_raInstanceId;
extern BOOL					g_ShowTitles;
extern BOOL					g_AutoStart;


/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_COMMAND(ID_AUDIO_CONSOLEOPTIONS_VOLUME, OnAudioConsoleoptionsVolume)
	ON_COMMAND(ID_AUDIO_CONSOLEOPTIONS_BUTTONS, OnAudioConsoleoptionsButtons)
	ON_COMMAND(ID_AUDIO_CONSOLEOPTIONS_STATUSBAR, OnAudioConsoleoptionsStatusbar)
	ON_COMMAND(ID_AUDIO_PREFERENCES, OnAudioPreferences)
	ON_COMMAND(ID_AUDIO_SHOWSTATISTICS, OnAudioShowstatistics)
	ON_COMMAND(ID_FILE_OPENURL, OnFileOpenurl)
	ON_COMMAND(ID_FILE_OPENFILE, OnFileOpenfile)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
}

CMainFrame::~CMainFrame()
{

}


BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	//  set up what we want the window to look like
	cs.style = WS_OVERLAPPED | WS_CAPTION | WS_THICKFRAME | WS_SYSMENU | WS_MINIMIZEBOX;
	cs.cx    = 370;
	cs.cy    = 200;

	return CFrameWnd::PreCreateWindow(cs);
}


/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG


/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

void CMainFrame::OnAudioConsoleoptionsVolume() 
{
	// Add a volume control & clip info to our "custom console"
	
	// snag the menu of our window
	CMenu *M = CWnd::GetMenu();

	// if the console is active, then...
	if (g_raInstanceId) {

		if (g_ShowVolume == RACS_INFOVOLUMEBAR) {
			// if volume & clip info are already showing, set the global var
			//    g_ShowVolume to be 0x00, so that volume disappears when we
			//    OR all our control flags and send them to RaguiSetControlFlags()
			g_ShowVolume = 0x00;
			M->CheckMenuItem(ID_AUDIO_CONSOLEOPTIONS_VOLUME, MF_UNCHECKED);
			RaguiSetControlsFlags(g_raInstanceId, g_ShowVolume | g_ShowButtons | g_ShowStatus);
			
		} else {
		    // otherwise, turn volume controls back on
		    g_ShowVolume = RACS_INFOVOLUMEBAR;
			M->CheckMenuItem(ID_AUDIO_CONSOLEOPTIONS_VOLUME, MF_CHECKED);
			RaguiSetControlsFlags(g_raInstanceId, g_ShowVolume | g_ShowButtons | g_ShowStatus);			
		}

		// and update the view
		CWnd::InvalidateRect(NULL);
		CWnd::UpdateWindow();

	} else {
		CWnd::MessageBox("You need a console open first!", "Not so fast, Slick!");
	}
}


void CMainFrame::OnAudioConsoleoptionsButtons() 
{
	// Adds buttons to our "custom console"

	// Works the same way as OnAudioConsoleoptionsVolume()

	CMenu *M = CWnd::GetMenu();
	
	if (g_raInstanceId) {

		if (g_ShowButtons == RACS_BUTTONBAR) {
			g_ShowButtons = 0x00;
			M->CheckMenuItem(ID_AUDIO_CONSOLEOPTIONS_BUTTONS, MF_UNCHECKED);
			RaguiSetControlsFlags(g_raInstanceId, g_ShowVolume | g_ShowButtons | g_ShowStatus);

		} else {
		    g_ShowButtons = RACS_BUTTONBAR;
			M->CheckMenuItem(ID_AUDIO_CONSOLEOPTIONS_BUTTONS, MF_CHECKED);
			RaguiSetControlsFlags(g_raInstanceId, g_ShowVolume | g_ShowButtons | g_ShowStatus);
		}

		CWnd::InvalidateRect(NULL);
		CWnd::UpdateWindow();

	} else {
		CWnd::MessageBox("You need a console open first!", "Not so fast, Slick!");
	}
}


void CMainFrame::OnAudioConsoleoptionsStatusbar() 
{
	// Adds a status bar to our "custom console"

	// works the same way as OnAudioConsoleoptionsVolume()

	CMenu *M = GetMenu();
	
	if (g_raInstanceId) {

		if (g_ShowStatus == RACS_STATUSBAR) {
			g_ShowStatus = 0x00;
			M->CheckMenuItem(ID_AUDIO_CONSOLEOPTIONS_STATUSBAR, MF_UNCHECKED);
			RaguiSetControlsFlags(g_raInstanceId, g_ShowVolume | g_ShowButtons | g_ShowStatus);
		
		} else {
		    g_ShowStatus = RACS_STATUSBAR;
			M->CheckMenuItem(ID_AUDIO_CONSOLEOPTIONS_STATUSBAR, MF_CHECKED);
			RaguiSetControlsFlags(g_raInstanceId, g_ShowVolume | g_ShowButtons | g_ShowStatus);
		}

		CWnd::InvalidateRect(NULL);
		CWnd::UpdateWindow();

	} else {
		CWnd::MessageBox("You need a console open first!", "Not so fast, Slick!");
	}
}


void CMainFrame::OnAudioPreferences() 
{
	//  this simple function call allows the user to change all sorts of
	//  RealAudio Parameters
	if (g_raInstanceId) {
		RaguiEditPreferences(g_raInstanceId);
	}
}

void CMainFrame::OnAudioShowstatistics() 
{
	if (g_raInstanceId) {
		// this visibility check check is totally unneccesary; it's used here to show how to call
		// RaguiIsStatisticsVisible()
		if ( RaguiIsStatisticsVisible(g_raInstanceId) ) {
			MessageBox("The statistics window is already visible.  I will close it for you.", "Statistics Info:");
		}
		// this call acts like a toggle... if they're visible, they go away.  If they're
		// not visible, they get shown.
		RaguiHideShowStatistics(g_raInstanceId);	
	}
}

void CMainFrame::OnFileOpenfile() 
{
	//  user wishes to open a local file
	char	     szFilename[256];
	CFileDialog* fileDlg;
	
	BOOL bOpenFileDialog 	= TRUE;
	LPCTSTR lpszDefFileName	= "thankyou.ra";
	DWORD dwFlags 		 	= OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
	LPCTSTR lpszFilter   	= "RealAudio Files (*.ra)|*.ra|RPM Files (*.rpm)|*.rpm|All Files (*.*)|*.*||";
	
	fileDlg = new CFileDialog(bOpenFileDialog, NULL, lpszDefFileName, dwFlags, lpszFilter, NULL);
	
	CString Caption;
	Caption.LoadString(IDS_URLDLG_TITLE);				
	
	fileDlg->m_ofn.lpstrTitle = Caption;
	lstrcpy(szFilename,fileDlg->m_ofn.lpstrFile);
	fileDlg->m_ofn.nMaxFile   = 256;
	fileDlg->m_ofn.lpstrFile  = szFilename; 
  	if (fileDlg->DoModal ()   == IDOK)
	{
		if (g_raInstanceId)
		{
			// send the file to ragui
			RaguiSetSource(g_raInstanceId, szFilename);

			// autostart if we want to
			if (RaguiSetAutoStart(g_raInstanceId, g_AutoStart) != PN_NO_ERROR)
				MessageBox("File cannot AutoStart");
		}
	} 
	delete fileDlg;
}

void CMainFrame::OnFileOpenurl() 
{
	//  user wishes to open a local file
	CURLDlg* URLDlg;
	
	URLDlg = new CURLDlg(NULL);
	
  	URLDlg->DoModal(); 

	delete URLDlg;
	
}
