/////////////////////////////////////////////////////////////////////////////
//
//      DO_RADLG.H
//
//      constant and function definitions for URL dialog box 
//
//      Bridie Saccocio           5/20/96
//
//      Copyright �1995,1996 Progressive Networks, Inc.  All rights reserved.
//
//

//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by do_ra.rc
//
#define IDD_OPEN_URL                    106
#define IDC_SERVER                      1006
#define IDC_RESOURCE                    1007
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
