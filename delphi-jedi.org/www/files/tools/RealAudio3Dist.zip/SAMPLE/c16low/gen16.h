/////////////////////////////////////////////////////////////////////////////
//
//      GEN16.H
//
//      function definitions for Gen16.C 
//
//      Bridie Saccocio           5/20/96
//
//      Copyright �1995,1996 Progressive Networks, Inc.  All rights reserved.
//
//

BOOL InitApplication(HANDLE);
BOOL InitInstance(HANDLE, int);
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK About  (HWND, UINT, WPARAM, LPARAM);
