/*
** Error.c
**
** Version 1.1
**
** Program to introduce errors in an input stream.
**
** Stupid, inefficient, and not very scientific.
**
** Seth Robertson
** seth@ctr.columbia.edu
*/

#include <stdio.h>
#include <math.h>
#include <sys/types.h>

char readbit()
{
  static char save;
  static int bits = 0;

  if (!bits)
    {
      if (fread(&save,1,1,stdin) < 1)
	return(-1);

      bits = 8;      
    }

  bits--;
  return((save&(1<<bits))>>bits);
}

writebit(bit)
char bit;
{
  static char save = 0;
  static int bits = 8;

  save |= ((bit & 0x01) << --bits);

  if (!bits)
    {
      if (fwrite(&save,1,1,stdout) < 1)
	perror("fwrite");

      bits = 8;
      save = 0;
    }
}


double drand48();

main(argc,argv)
int argc;
char *argv[];
{
  char bit;
  u_long errors = 0;
  double error_rate = .001;
  int c;
  int errflg=0;
  extern char *optarg;
  extern int optind, opterr;

  while ((c = getopt(argc,argv,"e:")) != -1)
    switch(c)
      {
      case 'e':
	error_rate=atof(optarg);
	break;
      case '?':
	errflg++;
	break;
      }

  if (error_rate > 1.0 || error_rate < 0.0)
    {
      fputs("Error must be between 0 and 1\n",stderr);
      errflg++;
    }

  if (errflg)
    {
      fprintf(stderr,"Usage: %s [-e error-rate]\n",argv[0]);
      exit(2);
    }

  srand48(time(0)%getpid());

  while ((bit = readbit()) >= 0)
    {
      if (drand48() < error_rate)
	{
	  bit = !bit;
	  errors++;
	}

      writebit(bit);
    }

  fprintf(stderr,"%d Errors introduced\n",errors);
}
