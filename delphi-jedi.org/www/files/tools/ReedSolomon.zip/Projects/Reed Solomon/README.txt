
Reed-Solomon Error Correction Routines.

This is a bunch of R-S stuff collected from the net (from
tmoore@ewu.uucp) I took the provided program and then modified it so
that it is potentially useful for humans (the provided program is a
proof-of-principle one). It takes its standard input and either
encodes or decodes it.

However, that is also the state of the program I generated out of the
demo program.  As far as I can tell it works, but I made some rather
rash assumptions which need to be confirmed by someone who knows what
they are doing.  Also, the program was rather more wasteful of
(output) space than is strictly needed (I think I waste somewhere
around 1/15 by being too lazy to keep track of half-bytes.  This
improves redundancy by some, but not by the same amount as the space I
waste)

So take it with a grain of salt and hopefully it will serve as an
inspiration for someone to do it the right way.



Example:

ReedSolomon -e < Error | Error | ReedSolomon -d > bar
cmp Error bar

Seth Robertson
seth@ctr.columbia

(with the Reed-Solomon code written by:)
Simon Rockliff, University of Adelaide   21/9/89
