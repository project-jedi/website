import java.net.*;
import java.io.*;

public class PageGrabber{

  public static void main (String args[])
  {
    String html = "";
    if (args.length > 0)
    {
      PageGrabber pg = new PageGrabber();
      html = pg.Fetch(args[0]);
      System.out.println(html);
    }
    else
    {
      System.out.println("Usage: PageGrabber URL");
      System.out.println();
      System.out.println("Example:\n");
      System.out.println("  PageGrabber http://www.borland.com/index.html");
    }
  }

  public static String FetchS(String inputURL)
  {
    PageGrabber pg = new PageGrabber();
    return pg.Fetch(inputURL);
  }

  public String Fetch(String inputURL)
  {
    return GetHTML(inputURL);
  }

  private String GetHTML(String inputURL)
  {
    String html = "";
    String thisLine = "";
    URL url;

    try
    {
      url = new URL(inputURL);

      try
      {
        BufferedReader theData = new BufferedReader(new InputStreamReader(url.openStream()));
        try
        {
          while ((thisLine = theData.readLine()) != null)
          {
            html = html + thisLine;
          }
        }
        catch (Exception e)
        {
          System.err.println("1." + e);
          html = e.toString();
        }
      }
      catch (java.io.FileNotFoundException e)
      {
        System.err.println("2." + e);
        html = e.toString();
      }
      catch (java.net.UnknownHostException e)
      {
        System.err.println("3." + e);
        html = e.toString();
      }
      catch (Exception e)
      {
        System.err.println("4." + e);
        html = e.toString();
      }
    } 
    catch (MalformedURLException e)
    {
      System.err.println(inputURL + " is not a parseable URL");
      System.err.println("5." + e);
      html = e.toString();
    }
    return html;
  }
}

