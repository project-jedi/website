     Java Native Interface for Delphi

This conversion allows to call Java programs from Delphi
and Delphi programs (DLLs) from Java. Data can be exchanged.
Since Java programs are platform independent it also works
for Linux.
All programs developed with Kylix beta are under Non
Disclosure Agreement so the testing had to be done in a
one way fashion. The conversion was forwarded to a
Kylix developer who reported back that it works.

This version has been stripped of the Linux specific parts.
It will be replaced with the full version the instant Kylix
is released.

For all who are not familiar with JEDI conversions:
JNI.par is the conversion with IFDEFs in it. For a Borland
compliant conversion the IFDEFs have to be stripped completely.
The resulting file is JNI.bor. The JNI.pas file is a copy of
JNI.bor.
This means that you should copy and use the JNI.par file to
get the full potential of this conversion.
The JNI_MD.INC file is the same for all versions (even Linux).

[KNOWN ISSUES]
The dynamic loading of the DLLs is not state of the JEDI art.
This will be changed in the multiplatform version for
Windows and Linux. Currently the Linux version is under
NDA for Kylix beta.
We had no time for another test cycle and the API will
not change from that.
