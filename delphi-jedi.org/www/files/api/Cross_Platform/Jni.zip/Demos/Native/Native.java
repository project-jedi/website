/****************************************************************************
 *
 *  Native.java
 *
 *  This code implements the interface to the Delphi code.
 *
 *
*/
class Native {

    // multiplies 2 integers and returns the result
  native public int multiplyIntegers(int op1, int op2);

    // initialize an array of bytes with the value 'value'
  native public void initializeByteArrayOnce(byte[] array, byte value);

    // Initializes an array of elements 'count' times with value 'value'
    // The native method is actually overloaded to provided the functionality
    // for the previous method 'initializeByteArrayOnce'. See Native.dpr
    // for details on how to overload native methods.
  native public void initializeByteArray(byte[] array, int count, byte value);

    // Used to test the code during upgrade to the JEDI standard
  native public void testAllTypesD(boolean bool, byte b, char c, int i, long l, float f, double d);

    // Displays the version of the JVM
  native public void printVersion();

    // guess?
  native public void displayHelloWorld();

    // Sieves prime numbers
  native public static int countPrimes(byte[] abFlags);

    // Pass a 2-D array of bytes to be printed and modified
  native public void pass2DByteArray(byte[][] array);

    // Prints all members of this class by using callbacks to the method
    // 'toString' below
  native public String toStringWithPrint();

    // Prints a Java String in native code and returns a Java String
  native public String printLine(String text);

    // Prints w, x, y, and z using native code (no callback to this class)
  native public void printWXYZ();

    // Causes an exception, doesn't handle it in native code
  native public void causeException();

    // Causes an exception, handles it in native code
  native public void handleException();

    // Prints each element of the objArray using a callback to the object's
    // 'toString' method
  native public void printObjectArray(Object[] objArray, boolean Print);

    // Creates, allocates, and initializes an array or Rectangles in native
    // code and returns the array to Java
  native public java.awt.Rectangle[] returnRectArray(int size);

    // No arguments, no return value
  native public void VoidVoid();

    // For timing test of C++ calling back to Java
  native public void callbackVoid(int Count);

    // Loads the file Native.DLL at run-time
  static {
    System.loadLibrary("Native");
  }

    // Primitive types, and a string
  String string_;
  boolean boolean_;
  byte byte_;
  char char_;
  double double_;
  float float_;
  int int_;
  long long_;
  short short_;

    // To test accessing public/private static/non-static
  public String w;
  public int x;
  private int y;
  public static int z;

    // Constructor
  public Native()
  {
    boolean_ = true;
    byte_ = 19;
    char_ = 'A';
    double_ = 3.1415926535;
    float_ = 10.2f;
    int_ = 123456;
    long_ = 987654321;
    short_ = 12345;
    string_ = "This is a Java string";

    w = "a Native String";
    x = 5;
    y = 11;
    z = 20;
  }

	public static void printHello()
  {
    System.out.println("Hello from Java!");
  }

    // A good thing to have
  public String toString()
  {
    String str = "Native[" +
                 "x=" + x +
                 ",y=" + y +
                 ",boolean_="  + boolean_ +
                 ",byte_=" + byte_ +
                 ",char_=" + char_ +
                 ",double_=" + double_ +
                 ",float_=" + float_ +
                 ",int_=" + int_ +
                 ",long_=" + long_ +
                 ",short_=" + short_ +
                 ",string_=" + string_ +
                 "]";

    return str;
  }

  public void voidFunc()
  {
  }

  public void testAllTypes(boolean bool, byte b, char c, int i, long l, float f, double d)
  {
    System.out.println(  "boolean = " + bool + ", "
                       + "byte = " + b + ", "
                       + "char = " + c + ", "
                       + "int = " + i + ", "
                       + "long = " + l + ", "
                       + "float = " + f + ", "
                       + "double = " + d);
  }
}
