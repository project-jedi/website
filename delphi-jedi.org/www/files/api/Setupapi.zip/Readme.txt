[KNOWN ISSUES]

The following types are declared at the top of the SetupApi interface unit.
These are external to setupapi.h but are not yet defined in Windows.pas. The
ones with the _PTR suffix are for compatibility with 64 bit Windows 2000.

- PPWSTR    = ^PWideChar;
- PPASTR    = ^PAnsiChar;
- PPSTR     = ^PChar;
- PHICON    = ^HICON;
- ULONG_PTR = DWORD;
- DWORD_PTR = DWORD;
- UINT_PTR  = DWORD;

The following constant is declared at the top of the SetupApi interface unit.
This constant is external to setupapi.h but is not yet defined in Windows.pas.

- ANYSIZE_ARRAY = 1;

[COMPILER DIRECTIVES]

- USE_SP_DRVINFO_DATA_V1

Controls whether the TSPDrvInfoData type is defined as TSPDrvInfoDataV1
(USE_SP_DRVINFO_DATA_V1 defined) or TSPDrvInfoDataV2 (not defined). The default
is TSPDrvInfoDataV2.

[USING PPSTR]

The PPSTR type refers to an array of strings. This is a type which is quite
akward to use in Delphi so we have provided a number of routines to help with
that.

StringsToPCharArray converts a TStrings into a PPSTR
PCharArrayToStrings converts a PPSTR into a TStrings
FreePCharArray frees the memory associated with a PPSTR

Note that the TStrings object and PPSTR have independent lifetimes since the
strings contained in them are copied when using these routines. Also, once
finished with a PPSTR you must use FreePCharArray() to free it's memory

function StringsToPCharArray(var Dest: PPSTR; const Source: TStrings): PPSTR;
var
  i:    Integer;
  s:    string;
  list: array of PChar;
begin                 
  Dest  := AllocMem((Source.Count + 1) * SizeOf(PChar)); // one more for an extra nil pointer
  SetLength(List, Source.Count + 1);
  for i := 0 to Source.Count - 1 do
  begin
    s := Source[i];
    list[i] := StrAlloc(Length(s) + 1);
    StrPCopy(list[i], s);
  end;
  list[Source.Count] := nil;
  Move(list[0], Dest^, (Source.Count + 1) * SizeOf(PChar));
  Result := Dest;
end;

procedure PCharArrayToStrings(const Dest: TStrings; const Source: PPSTR; const Count: Integer);
var
  i:    Integer;
  list: array of PChar;
begin
  SetLength(list, Count);
  Move(Source^, list[0], Count * SizeOf(PChar));
  Dest.Clear;
  for i := 0 to Count - 1 do
    Dest.Add(List[i]);
end;

procedure FreePCharArray(var Dest: PPSTR; const Count: Integer);
var
  i:    Integer;
  list: array of PChar;
begin
  SetLength(list, Count);
  Move(Dest^, list[0], Count * SizeOf(PChar));
  for i := 0 to Count - 1 do
    StrDispose(list[i]);
  FreeMem(Dest, (Count + 1) * SizeOf(PChar));
  Dest := nil;
end;
