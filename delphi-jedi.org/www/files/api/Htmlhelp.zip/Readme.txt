See JediHtmlHelp.chm in the Help folder.
You will need to have HTML Help installed to view that file.
You can download HTML Help from http://msdn.microsoft.com/workshop/author/htmlhelp/