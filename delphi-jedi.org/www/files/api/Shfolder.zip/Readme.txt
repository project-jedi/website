Extra Shell Folder API.

ShFolder is a very simple API, which normally is integrated in shlobj.h, but
is also available as a separate ShFolder.h. It interfaces the shfolder.dll,
which is normally installed with Internet Explorer 4 or 5.

Included is a very simple demo, which will show the folders defined in this
API on your system

Rudy Velthuis
rvelthuis@gmx.de
