[KNOWN ISSUES]

The TPdhBrowseDlgConfig record type contains a field named dwConfigFlags which
was a bitfield in the original C/C++ header file. Unfortunately Object Pascal
does not provide direct support for bitfields. Therefore this field was translated
as a DWORD and the following constants have been added.

  PDH_CF_INCLUDEINSTANCEINDEX    = 1 shl 0;
  PDH_CF_SINGLECOUNTERPERADD     = 1 shl 1;
  PDH_CF_SINGLECOUNTERPERDIALOG  = 1 shl 2;
  PDH_CF_LOCALCOUNTERSONLY       = 1 shl 3;
  PDH_CF_WILDCARDINSTANCES       = 1 shl 4;
  PDH_CF_HIDEDETAILBOX           = 1 shl 5;
  PDH_CF_INITIALIZEPATH          = 1 shl 6;
  PDH_CF_DISABLEMACHINESELECTION = 1 shl 7;
  PDH_CF_INCLUDECOSTLYOBJECTS    = 1 shl 8;
  PDH_CF_RESERVED                = DWORD($FFFFFE00);

You can use this field by or-ing together the constants as followed:

var
  Config: TPdhBrowseDlgCongif;
begin
  Config.dwConfigFlags := PDH_CF_SINGLECOUNTERPERADD or
                          PDH_CF_SINGLECOUNTERPERDIALOG or
                          PDH_CF_INCLUDECOSTLYOBJECTS;
  ...
end;

[IMPLEMENTATION]

[TESTER REPORTS]

[ASSOCIATED WORK]

[FILE MAPPING]

[DEFINES]

[BUGLIST&FIXES]
