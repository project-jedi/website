
Object Pascal Speech API (V 4.0) Translation Readme

KNOWN ISSUES

SID_ constants are necessary so {#BEGIN} {$} {#END} can be used in Interface Definitions. There are 2 occurrences of each GUID string. We only mention this because if a GUID string is found to be incorrect it will probably be incorrect in 2 places.

IMPLEMENTATION

Installation - To use these conversions you must have the SAPI operating system extension binaries and SAPI compliant speech engines installed on the system. You can download these parts from www.microsoft.com/iit/. I highly recommend that you download the "Suite" because includes everything you need, but its big (40+MB), otherwise download the SAPI SDK (7 MB). The smaller download will install the SAPI binaries but no engines. The engines can be downloaded seperately. Note that it is the Dictation engine that accounts for the large size of the Suite download so if you don't need to implementation Dictation speech recognition then just download the individual parts.

Documentation - I am still planning to do a help file as soon as time allows. As yet, no documentation specific to this OP translation exists, however the documentation that comes in the SAPI SDK from Microsoft (www.microsoft.com/iit/) can be used as long as you keep the following in mind.
1) The names of all objects, structures, methods, and constants have been kept the same as in the original Microsoft C++ header.
2) Except in cases of parameters which were originally pointers in the C++ header and were converted to var in the Object Pascal translation. In this case the first p in the parameter name was dropped.
3) If the original C++ method name was "Set" then the method name was changed to "DoSet" in the translation. This was to avoid conflicts with the OP set keyword.
4) If, for a given method, the C++ version used the same parameter name twice then the Object Pascal translation made some meaningful differentiation to make the names unique.
5) In a few cases Microsoft did not document or name parameters, in these cases the parameters were called "Undocumented1, Undocumented2, etc." In the Object Pascal translation.

TESTER REPORTS

Bob Bortolin submitted the included text to speech demo project as the result of his testing.

ASSOCIATED WORK

In addition to the work found here, the commercial VCL component Set DTalk (by O&A Productions www.o2a.com/DTalk) uses this translation as the basis for its components.

FILE MAPPING

header file	interface units
-----------	---------------
speech.h	speech.pas
spchtel.h	spchtel.pas

DEFINES

There are currently no conditional defines in these two units

BUG LIST and FIXES

We know of no bugs or outstanding problems with these translations and none have been reported.

If you are reading this then you probably got it along with the Object Pascal translation of the Microsoft Speech API version 4.0 header (speech.h).

You can get a copy of the MS Speech API (SAPI) along with speech recognition and speech synthesis engines from www.microsoft.com/iit/.

The Object Pascal translation consists of two files; Speech.pas and Spchtel.pas. Speech.pas contains most of the API while Spchtel.pas contains only objects which lie in a middle ground between TAPI and SAPI.


The translation follows the "Pascal Header Translation Specification" (ver 1.01) published by Inprise/Borland.Com.

You may retrieve the latest version of this file at the Project JEDI home page, located at http://www.delphi-jedi.org.

Please address any comments, suggestions or bug reports to alecb@o2a.com .

License
The contents of this file are subject to the Mozilla Public License Version 1.1 (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at http://www.mozilla.org/MPL/MPL-1.1.html 

Software distributed under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for the specific language governing rights and limitations under the License.

Modification history
The Original Code is: SPEECH.PAS, was released July 28, 1999. 

Contributors
Original tanslation by Alec Bergamini (Out & About Productions - www.o2a.com) 
Extensive code review and suggestions by Alex Hekstra. 
TTS demo application by Bob Bortolin. 
This is a work in process done under the auspices of the JEDI project (www.delphi-jedi.org )


Additional Notes
This header translation has been extensively tested and the same header translation used in the commercial speech component set DTalk. DTalk is a rich set of native Delphi components designed to greatly simplify the task of building speech enabled application in Delphi. If you would like more information about the DTalk component set visit the O&A Productions web site at www.o2a.com. A demo version of the complete set is available for download at this site.

May the force by with you.


