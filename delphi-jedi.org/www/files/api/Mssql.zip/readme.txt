Ever wanted to use Delphi with MS SQL server without
the heartache of setting up the BDE or ODBC or SQL Links?
Every wanted 'really fast' database access?  I did, so
I set out to convert the huge MS SQL C headers for use with
Delphi.  Never did finish though, discovered I could do 
about anything I wanted to with the little I did translate, 
connect, do a query, insert, update, delete, call stored
procedure...  My work is here for you to use (or abuse) for
free.  Since it is free, I give you absolutely no warranty,
I works for me, sorry if it doesn't for you.

MSSQL16.PAS is for Delphi 1 (16 bit) and MSSQL32.PAS is for
Delphi 2/3 (32 bit).  If you don't have the MS SQL Client
installed it won't work, sorry.

Happy Coding,
Ed Lyk
