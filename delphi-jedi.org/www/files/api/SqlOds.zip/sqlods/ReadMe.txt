Author:          Fran�ois PIETTE
Initial release: September 02, 2001
Version:         1.00
Description:     Microsoft Open Data Services (SQL-Server) interface unit
                 for Extended Stored Procedures (opends60.dll)
Author:          Francois PIETTE
                 http://www.overbyte.be
                 francois.piette@overbyte.be
Legal stuff:     The contents of this file are used with permission, subject to
                 the Mozilla Public License Version 1.1 (the "License"); you
                 may not use this file except in compliance with the License.
                 You may obtain a copy of the License at
                 http://www.mozilla.org/MPL/MPL-1.1.html

                 Software distributed under the License is distributed on an
                 "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
                 implied. See the License for the specific language governing
                 rights and limitations under the License.

Files:           SqlOds\ReadMe.txt                 The file you are reading
                 SqlOds\Infos.txt                  Delphi JEDI info file
                 SqlOds\Demos\xp_delphi.dpr        Sample application
                 SqlOds\Pas\SrvTypes.pas           Server types constants
                 SqlOds\Pas\SrvConst.pas           API constants
                 SqlOds\Pas\SrvDbTyp.pas           Database datatypes
                 SqlOds\Pas\SrvMisc.pas            Miscelaneous constants
                 SqlOds\Pas\SrvStruc.pas           API data structures
                 SqlOds\Pas\SrvTok.pas             TDS tokens
                 SqlOds\Pas\SrvApi.pas             API functions



