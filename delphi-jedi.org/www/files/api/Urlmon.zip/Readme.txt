URLMON URL Moniker Interface.

This is a newer version of the file you find in the Delphi 5 Source\RTL\Win
directory. That file is a conversion of a November 1997 header, whereas this
is a conversion of a March 1999 header.

Have fun with it.

If you have any problems or other issues with it, please let me know. My email
is in the comment at the top of the .pas file and in info.txt.

    Rudy Velthuis, team captain (and only team member).

[KNOWN ISSUES]

[IMPLEMENTATION]

[TESTER REPORTS]

[ASSOCIATED WORK]

[FILE MAPPING]

[DEFINES]

[BUGLIST&FIXES]

01 Mar 2000: changed "pcchResult: DWORD" to "out pcchResult: DWORD" in the
             declaration for IInternetProtocolInfo.ParseUrl. 