ODBC/SQL APIs for Microsoft SQL Server

Version: MsOdbc04.zip

  This file replaces Odbc3.zip, Odbc2.zip and Odbc1.zip, including
  all the contents of those files.


Contents:

 - OdbcVer.pas
 - Odbcss.pas
 - OdbcInst.pas
 - Sql.pas
 - SqlDb.pas  ** New **
 - SqlExt.pas
 - SqlFront.pas  ** New **
 - SqlTypes.pas


Notes for Odbc4.zip:

 The included files compile under Delphi 2, Delphi 3 and Delphi 4 Beta 1.

 New files include SqlDb.pas and SqlFront.pas.

 In SqlDb.pas, the function dbfcmd() is not supported as
 of yet. It will likely take a stub function of some sort
 to support this function since it uses C/C++ open parameters.
 The dbfcmd() only formats the strings like the sprintf()
 function does in C/C++.

 The dbfcmd() function is actually a formatting version of
 dbcmd(), so one only needs to format the string before sending
 it to dbcmd() to obtain the same effect. dbfcmd() only wraps
 the sprintf() functionality, in fact, it calls sprintf() before
 sending the string to dbcmd(). If you need more information on
 dbfcmd(), or a clarification of its functionality, then look at
 "Programming DB-Library for C Help", filename Dblibw.hlp, and
 search for "dbfcmd" in the search index of the help file.

 The following functions have not been opened yet, since the
 exact nameless parameters are not known as of yet from the C
 code or in any of the documentation that's been found to this
 point.

   - dbenlisttrans()
   - dbenlistxatrans()
   - dbreadpage()
   - dbrpwset()
   - dbwritepage()

 At this time, these functions are undocumented by Microsoft.

 If anyone needs anyone of these functions opened, please email
 Douglas Kiely <DougK@ktek.com>.


Notes for Odbc3.zip:

 The included files compile under Delphi 2 and Delphi 3.

 Added compiler directives for ODBC_Ver30 to the static
 imports of Sql.pas. It was missing from previous versions
 of Sql.pas, and would have cause compiler errors when
 statically linking to versions of ODBC32.DLL below
 version 3.0.


Notes for Odbc2.zip:

 The included files compile under Delphi 2 and Delphi 3.

 Sql.pas and SqlExt.pas now have their static import
 dll names included in the implementation section.


Notes for Odbc1.zip:

 The following files compile under Delphi 2 and Delphi 3.

 Sql.pas and SqlExt.pas each have a few functions that
 don't have their static import dlls known as of yet.
 They're external DLL names are marked with a const
 UNKNOWN. We should know their DLL names any day now. As
 soon as we do, they'll be added.
