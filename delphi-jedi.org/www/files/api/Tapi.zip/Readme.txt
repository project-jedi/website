[CHANGES]

The last TAPI conversion was based on beta headers from the Platform SDK. This conversion has been
updated to the release headers as they are shipped with the July 2000 edition of the Platform SDK. 
The changes we're in TAPI 2.2 and TAPI 3.0 declarations only. Note, however, that a few constant definitions (their values) have changed between beta and release and therefore it's not recommended 
to use this conversion on a Win2K beta release or vice versa.

[KNOWN ISSUES]

This TAPI conversion is significantly different from previous conversions,
especially the first one released by Project JEDI. Applications that were
written to use earlier TAPI conversions will probably not compile with this
conversion because some of the types are declared differently. These older
applications will need to be modified so that their types used in them are
consistent with revised declarations in the new conversion."

The TAPI functions all return a Longint parameter. This is a signed integer!
However, a lot of constants which represent possible return values and have
their high bit set, are declared as DWORD which is an unsigned type. This will
cause compiler warnings when you attempt to compare a function result with any
of these constants. To supress those warnings you must cast the function result
to a DWORD.

[DIRECTIVES]

The directives can be controlled using the Tapi.inc include file which is
included in both Tapi.pas and TSPI.pas.

Note that TAPI10 is mutually exclusive with the other TAPIxx directives. TAPI20
through TAPI30 can be used together but when using the include file you only
need to define the highest version you want to use. For example, if you define
TAPI30 then TAPI20 through TAPI22 are automatically defined as well.

TAPI10  If defined the interface units support Tapi 1.x only
TAPI20  If defined the interface units support Tapi 2.0
TAPI21  If defined the interface units support Tapi 2.1
TAPI22  If defined the interface units support Tapi 2.2
TAPI30  If defined the interface units support Tapi 3.0
WIN32   Used in conjunction with TAPI10 to select between 16 and 32 bit Windows
        WIN32 must be defined to build Tapi 2.x and 3.x applications. This is
        done automatically by the include file.
_WIN64  If not defined the interface unit declares the DWORD_PTR type as DWORD.
        This type is used for compatibility with 64 bit Windows 2000