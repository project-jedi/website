This is a conversion of the LDAP header file (winldap.h) to Delphi.

The sample project is a shameless Find People clone and requires Delphi 4.x.

You can use these files at your own risk; there is no implied warranty.
Duplication on any media is prohibited without the author's explicit consent.

Luk Vermeulen (lvermeulen@seria.com)

[updates]

16 Feb 2000: The file was enhanced and made Jedi compliant.
16 Feb 2000: Demo was slightly modified.
20 Mar 2000: Corrected error in ldap_next_attribute. The first parameter (ld of type PLDAP)
             was falsely declared var.

Rudy Velthuis (rvelthuis@gmx.de)
