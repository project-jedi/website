Twain based Delphi Scanner Framework
------------------------------------

For more information about TWAIN
   http://www.twain.org

KNOWN ISSUES
- The translation was done for Delphi 4 and 5,
  but it should work for D2 and D3, too.

- A 16 Bit Version of twain.pas should also be
  possible, since the structures are designed by
  the Twain Working Group to be usable with 16 and
  32 Bit Windows. Of course the base types must be
  checked (especially TW_UINT32) and also check the
  function definition, but the rest should be ok.

DOCUMENTATION:
- Visit the Twain homepage and download the pdf file(s).
  You may also load and install the twain toolkit.

IMPLEMENTATION
- The file uses packed records instead of using the
  alignment compiler switch. This is done because the
  original include file uses two byte alignment, but 
  only a few structures were really affected: For these 
  the extra alignment bytes were added manually. 
  (I checked the 'SizeOf's for all compiled structures)
- There is no fix linked version unit to the twain32.dll,
  the DLL must always be loaded by LoadLibrary:
  It is not very common to link a program directly to
  the twain.dll, because most programs work perfect
  without twain support, the twain features are just
  disabled for this case.
  Since there are only two functions exported by
  the Twain functions and normal programs need only
  one (DSM_Entry) this is not very complicated.
  And it is identical to normal C implementations.
- Twain does not use Unicode at all, so the .par file 
  is identical to the .pas file
- The original twain.h file does not use any Macros,
  so no functions are needed ;-)

EXAMPLE PROGRAM
- Sorry for the User Interface ;-)
- to compile it, you must have the twain.pas unit in your
  search path (..\pas for example)
- the code is a rough translation of the C Example
  program from the Twain Toolkit and is only a first
  try for a real framework.

TESTER REPORTS
  nothing yet

BUG LIST and FIXES
  nothing known yet
