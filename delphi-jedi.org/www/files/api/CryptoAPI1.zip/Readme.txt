This document is Copyright � 1997-98 Project JEDI.
Visit the JEDI home page at:http://www.delphi-jedi.org/
--------------------------------------------------------

--------------------------------------------------------
CryptoApi version 1.1
Delphi binding version 1.0.3
--------------------------------------------------------

structure of package:

/Api
  wincrypt.pas -> binding for cryptoapi 1.1
/Comp
  CryApi.pas   -> simple example component
  CryApi.dcr   -> bitmap resource fo component
/Example
  mainForm.pas -> example of using the component
  mainForm.dfm
  CryFile.dpr
/Help
  wincrypt.rtf -> help project for cryptoapi binding
  WINCRYPT.fts
  wincrypt.GID
  wincrypt.ph
  wincrypt.toc
  WINCRYPT.CNT
  WINCRYPT.HPJ
  JEDIMAIN.BMP
  WINCRYPT.HLP
  
NOTE: help project is not complete.
TODO: tutorial for programming with cryptoapi, maybe a translation in english
      from italiam of a my article 'Usare le CryptoApi in Delphi' ('Using CryptoApi
      with Delphi').
      
Massimo Maria Ghisalberti
O.B.you!
obyou@tin.it
nissl@tin.it (personal)
(-- JEDI Project JediCore Conversion Member --)