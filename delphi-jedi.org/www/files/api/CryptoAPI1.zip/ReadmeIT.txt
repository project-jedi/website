Esempio di crittografazione di file usando le
CryptoApi di Microsoft.
Nella Directory Api, la traduzione dell'header wincrypt.h
Nella directory Comp, un semplice componente usato dall'applicazione

Copyright Massimo Maria Ghisalberti
via Eugubina 66/d
06125 PERUGIA
nissl@tin.it
O.B.you!
obyou@tin.it

Il codice � FREEWARE, quindi siate liberi di usarlo, purch�
manteniate il copyright e menzionate O.B.you! nei codici
risultanti da questo.
