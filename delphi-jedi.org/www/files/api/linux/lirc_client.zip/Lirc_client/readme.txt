This API conversion is part of the Project JEDI - Linux API Library
(http://www.delphi-jedi.org). To report bugs and issues please contact either
the team captain (as mentioned in the ini.txt file) or enter them into our
offical bug tracking system (http://projectjedi.sourceforge.net/issuetracker/)

- Your Project JEDI Team
