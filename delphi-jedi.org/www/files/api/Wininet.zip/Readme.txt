Windows Internet Extension interface unit

This is the newest version of the WinInet.h from the Platform SDK.

[KNOWN ISSUES]

Until Delphi has an entry in Windows.pas for types like DWORD_PTR, I'll have
to define it myself. Please remove the definition of this type as soon as
it is defined in the original Windows.pas

[BUGFIXES]

before:
function InternetGetConnectedState(var lpdwFlags: LPDWORD;

after:
function InternetGetConnectedState(var lpdwFlags: DWORD;

June 22, 2001 Marcel van Brakel

---

Have fun with it.

Rudy Velthuis
rvelthuis@gmx.de
