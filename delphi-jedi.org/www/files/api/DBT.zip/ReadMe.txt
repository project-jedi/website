KNOWN ISSUES

None at the moment

IMPLEMENTATION

DBT.Pas contains constants, structures which are used by broadcast devices. 

TESTER REPORTS

None

ASSOCIATED WORK

*DeviceChange is a component which detects notifications and fires events according to these notifications and selected devices

*CDEvents is a component which uses some of the structures to detect CD removal and insertion

DEFINES

None


BUG LIST and FIXES

2000-01-27 

  * corrected the DBT_CONFIGMGPRIVATE constant to $7FFF instead of $7FF
  * Moved TWMDeviceChange from demo examples to dbt.pas as proposed by Robert Marquardt

2001-04-26

  * Robert Marquardt: I made the conversion Borland C++ Builder compatible and
  * and made some minor style changes