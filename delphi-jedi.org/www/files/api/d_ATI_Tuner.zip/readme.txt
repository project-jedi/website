ATI TUNER SDK DELPHI TRANSLATION README
---------------------------------------

First of all, please visit ATI Developer's Lair (at http://www.atitech.ca)
and download the TUNER SDK.(not the AMC SDK).This will give you proper 
documentation on the SDK functionality.

I have included a small sample program which will give you an ideea on how
to use the TUNER SDK.

Further works includes the Ati Multimedia Channel SDK, which will give you 
many more functions to access the ATI boards multimedia capabilities.

Over and out,
kick@mmxent.com - Delphi JEDI Project Member