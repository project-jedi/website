A declaration for IID_IPersistFile was added to MsTask.pas to enable the usage
of IPersistFile without having to include Ole2 in application. This declaration
was not in the original header file.

New demo program demonstrates virtually all interfaces/methods and therefore the 
original demo program has been excluded (it's 'obsolete'). 


August 2000, Marcel van Brakel.