Video for Linux for Kylix
-------------------------

The translation of the data structures of
'linux/videodev.h' can be found in the
V4LTypes unit. The ioctls are found in the
V4Lioctls unit.

The units V4L and V4LDevice contain the first
steps I did for some Video4Linux Kylix
Components, but there is just a bit for the
radio part implemented.

I don't need a copyright for the files, so
everything is freeware.

27.05.2001, utessel@gmx.de

