To rebuild, you must at each package right click and select "Options..." from the popup menu:

Then at the "Directories/Conditionals" page, at the "Output directory" field you must enter 
a full path to the directory "....\JEDI QuickTime\QuickTime\Delphi4\output", "....\JEDI QuickTime\QuickTimeUtilities\Delphi4\output", "....\JEDI QuickTime\QuickTimeComponents\Delphi4\output" for the "QuickTime", "QuickTimeUtilities" and "QuickTimeComponents" packages respectively

You can leave the rest of the options in that tab with relative paths as they already are set

That is for Delphi4 only (tried with Update Pack 3 installed, maybe some later update pack if existing fixes this problem)
