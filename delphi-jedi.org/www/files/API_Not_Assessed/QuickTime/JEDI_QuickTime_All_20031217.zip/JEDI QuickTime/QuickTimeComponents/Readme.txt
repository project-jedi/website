QuickTime Components - Readme.txt
last update: 16 Dec 2003 by George Birbilis (birbilis@kagi.com)

0. RELEASE HISTORY

* 10 Jun 2001 - first version donated to Delphi-JEDI (http://www.delphi-jedi.org)
* 01 Feb 2002 - reorganized subfolders
* 13 Apr 2002 - now the JQTFileDialog has its own icon and the .RES file it was requiring at link time has been removed
* 21 Apr 2002 - added "Delphi6" folder with "QuickTimeComponents" package for Delphi6 (won't compile, can't find "DsgnIntf.pas", at least when trying with Delphi6 Personal)
* 16 Dec 2003 - now compiling with Delphi6 too (couldn't rebuild for Delphi4, please rebuild yourself)

1. KNOWN ISSUES

These are Delphi components based on the QuickTime JEDI package

2. IMPLEMENTATION

this is a preliminary version, JQTFileDialog is not a fully functional component yet

3. TESTER REPORTS

Do send your comments at birbilis@kagi.com

4. ASSOCIATED WORK

see http://members.fortunecity.com/birbilis/QT4Delphi


5. FILE MAPPING

all units named in the pattern JQTxxx
